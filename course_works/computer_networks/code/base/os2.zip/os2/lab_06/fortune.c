#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/proc_fs.h>
#include <linux/string.h>
#include <linux/version.h>
#include <linux/vmalloc.h>

#define FILENAME "fortune_file"
#define DIRNAME "fortune_dir"
#define SYMENAME "fortune_sym"
#define PREFIX "+ fortune "

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Mikhail Salnikov");

static struct proc_dir_entry *dir = NULL;
static struct proc_dir_entry *file = NULL;
static struct proc_dir_entry *link = NULL;

static int pid = -1;

static int my_proc_open(struct inode *, struct file *);
static ssize_t my_proc_read(struct file *, char __user *, size_t, loff_t *);
static ssize_t my_proc_write(struct file *, const char __user *, size_t, loff_t *);
static int my_proc_release(struct inode *, struct file *);*

static struct proc_ops file_ops = {
    .proc_open = my_proc_open,
    .proc_read = my_proc_read,
    .proc_write = my_proc_write,
    .proc_release = my_proc_release};

static int my_proc_open(struct inode *inode, struct file *file)
{
    printk(KERN_INFO PREFIX "Open\n");
    return 0;
}

static int my_proc_release(struct inode *inode, struct file *file)
{
    printk(KERN_INFO PREFIX "Close\n");
    return 0;
}

static ssize_t my_proc_read(struct file *file, char __user *buf, size_t count, loff_t *ppos)
{
    printk(KERN_INFO PREFIX "Read\n");
    char info[256] = {0};
    int len;
    struct task_struct *task;

    if (*ppos > 0)
    {
        printk(KERN_INFO PREFIX "0\n");
        return 0;
    }

    if (pid == -1)
    {
        printk(KERN_INFO PREFIX "PID not set\n");
        return -EINVAL;
    }

    task = pid_task(find_vpid(pid), PIDTYPE_PID);
    if (!task)
    {
        printk(KERN_INFO PREFIX "Process with PID %d not found\n", pid);
        return -ESRCH;
    }

    snprintf(info, sizeof(info),
             "comm - %s\n"
             "pid - %d\n"
             "pcomm - %s\n"
             "ppid - %d\n"
             "state - %ld\n"
             "flags - %x\n"
             "prio - %d\n"
             "policy - %d\n"
             "exit_state - %d\n"
             "exit_code - %d\n"
             "exit_signal - %d\n"
             "utime - %lu\n"
             "stime - %lu\n"
             "lst - %lu\n",
             task->comm,
             task->pid,
             task->real_parent->comm,
             task->real_parent->pid,
             (long)task->__state,
             task->flags,
             task->prio,
             task->policy,
             task->exit_state,
             task->exit_code,
             task->exit_signal,
             task->utime,
             task->stime,
             task->last_switch_time);

    len = strlen(info);
    if (copy_to_user(buf, info, len))
        return -EFAULT;

    *ppos = len;
    printk(KERN_INFO PREFIX "%d\n", len);
    return len;
}

static ssize_t my_proc_write(struct file *file, const char __user *buf, size_t count, loff_t *ppos)
{
    printk(KERN_INFO PREFIX "Write\n");
    char temp_buf[16] = {0};
    int new_pid;
    int ret;

    if (count >= sizeof(temp_buf))
        return -EINVAL;

    if (copy_from_user(temp_buf, buf, count))
        return -EFAULT;

    temp_buf[count] = '\0';

    ret = kstrtoint(temp_buf, 10, &new_pid);
    if (ret != 0)
    {
        printk(KERN_INFO PREFIX "Invalid PID\n");
        return -EINVAL;
    }

    pid = new_pid;
    printk(KERN_INFO PREFIX "PID: %d\n", pid);

    return count;
}

static int __init fortune_init(void)
{
    printk(KERN_INFO PREFIX "Module loaded\n");

    dir = proc_mkdir(DIRNAME, NULL);
    if (!dir)
    {
        printk(KERN_ERR PREFIX "Failed to create directory\n");
        return -ENOMEM;
    }

    file = proc_create(FILENAME, S_IRUGO | S_IWUGO, dir, &file_ops);
    if (!file)
    {
        printk(KERN_ERR PREFIX "Failed to create file\n");
        return -ENOMEM;
    }

    link = proc_symlink(SYMENAME, NULL, "/proc/" DIRNAME "/" FILENAME);
    if (!link)
    {
        printk(KERN_ERR PREFIX "Failed to create symlink\n");
        return -ENOMEM;
    }

    return 0;
}

static void __exit fortune_exit(void)
{
    remove_proc_entry(SYMENAME, NULL);
    remove_proc_entry(FILENAME, dir);
    remove_proc_entry(DIRNAME, NULL);

    printk(KERN_INFO PREFIX "Module unloaded\n");
    printk(KERN_INFO PREFIX "-------------------------\n");
}

module_init(fortune_init);
module_exit(fortune_exit);
