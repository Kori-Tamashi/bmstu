/home/kori/bmstu/os2/lab_05/lab_05_02/md1.o
