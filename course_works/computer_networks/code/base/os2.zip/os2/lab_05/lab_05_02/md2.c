#include "md.h"
#include <linux/init.h>
#include <linux/module.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Salnikov Mikhail");

static int __init md_init(void) {
    printk("+ module md2 started!\n");
    printk("+ data string exported from md1 : %s\n", md1_data);
    printk("+ data returned md1_proc() is : %s\n", md1_proc());

    printk("md2 noexport from md1: %s\n", md1_noexport());

    return 0;
}

static void __exit md_exit(void) {
    printk("+ module md2 unloaded!\n");
}

module_init(md_init);
module_exit(md_exit);
