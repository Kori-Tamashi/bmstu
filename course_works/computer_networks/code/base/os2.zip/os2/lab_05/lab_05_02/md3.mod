/home/kori/bmstu/os2/lab_05/lab_05_02/md3.o
