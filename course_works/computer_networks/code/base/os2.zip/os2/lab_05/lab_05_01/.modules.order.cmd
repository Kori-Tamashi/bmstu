savedcmd_/home/kori/bmstu/os2/lab_05/lab_05_01/modules.order := {   echo /home/kori/bmstu/os2/lab_05/lab_05_01/module_first.o; :; } > /home/kori/bmstu/os2/lab_05/lab_05_01/modules.order
