#include <linux/init.h>
#include <linux/init_task.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/fs_struct.h>
#include <linux/path.h>


MODULE_LICENSE("GPL");
MODULE_AUTHOR("Mikhail Salnikov");


static void print_task_info(const char *prefix, struct task_struct *task)
{

    printk(KERN_INFO "my %s comm - %s, pid - %d, pcomm - %s, ppid - %d, "
                     "state - %ld, on_cpu - %d, flags - %x, prio - %d, policy - %d, "
                     "exit_state - %d, exit_code - %d, exit_signal - %d, "
                     "utime - %lu, stime - %lu, lst - %lu\n",
           prefix,
           task->comm,              
           task->pid,               
           task->real_parent->comm, 
           task->real_parent->pid, 
           (long)task->__state,     
           task->on_cpu,            
           task->flags,             
           task->prio,             
           task->policy,            
           task->exit_state,        
           task->exit_code,         
           task->exit_signal,       
           task->utime,             
           task->stime,
           task->last_switch_time);
}

static int __init mod_init(void)
{
    struct task_struct *task = &init_task;

    do
    {
        print_task_info("+ ", task);
    } while ((task = next_task(task)) != &init_task);

    print_task_info("+ CURRENT ", current);

    return 0;
}

static void __exit mod_exit(void) 
{
    printk(KERN_INFO "my + Good bye");
}

module_init(mod_init);
module_exit(mod_exit);