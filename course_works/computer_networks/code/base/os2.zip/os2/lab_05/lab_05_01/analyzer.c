#include <glob.h>
#include <stdlib.h>
#include <stdio.h>

void analyze_task_flags(unsigned int flags) {
    struct flag_info { unsigned int mask; const char *descr; };
    struct flag_info known_flags[] = {
        { 0x00000001, "PF_VCPU —  I'm a virtual CPU " },
        { 0x00000002, "PF_IDLE —  I am an IDLE thread " },
        { 0x00000004, "PF_EXITING —  Getting shut down " },
        { 0x00000008, "PF_POSTCOREDUMP —  Coredumps should ignore this task " },
        { 0x00000010, "PF_IO_WORKER —  Task is an IO worker " },
        { 0x00000020, "PF_WQ_WORKER —  I'm a workqueue worker " },
        { 0x00000040, "PF_FORKNOEXEC —  Forked but didn't exec " },
        { 0x00000080, "PF_MCE_PROCESS —  Process policy on mce errors " },
        { 0x00000100, "PF_SUPERPRIV —  Used super-user privileges " },
        { 0x00000200, "PF_DUMPCORE —  Dumped core " },
        { 0x00000400, "PF_SIGNALED —  Killed by a signal " },
        { 0x00000800, "PF_MEMALLOC —  Allocating memory " },
        { 0x00001000, "PF_NPROC_EXCEEDED —  set_user() noticed that RLIMIT_NPROC was exceeded " },
        { 0x00002000, "PF_USED_MATH —  If unset the fpu must be initialized before use " },
        { 0x00004000, "PF_USER_WORKER —  Kernel thread cloned from userspace thread " },
        { 0x00008000, "PF_NOFREEZE —  This thread should not be frozen " },
        { 0x00010000, "PF__HOLE__00010000 — " },
        { 0x00020000, "PF_KSWAPD —  I am kswapd " },
        { 0x00040000, "PF_MEMALLOC_NOFS —  All allocation requests will inherit GFP_NOFS " },
        { 0x00080000, "PF_MEMALLOC_NOIO —  All allocation requests will inherit GFP_NOIO " },
        { 0x00100000, "PF_LOCAL_THROTTLE — " },
        { 0x00200000, "PF_KTHREAD —  I am a kernel thread " },
        { 0x00400000, "PF_RANDOMIZE —  Randomize virtual address space " },
        { 0x00800000, "PF__HOLE__00800000 — " },
        { 0x01000000, "PF__HOLE__01000000 — " },
        { 0x02000000, "PF__HOLE__02000000 — " },
        { 0x04000000, "PF_NO_SETAFFINITY —  Userland is not allowed to meddle with cpus_mask " },
        { 0x08000000, "PF_MCE_EARLY —  Early kill for mce process policy " },
        { 0x10000000, "PF_MEMALLOC_PIN —  Allocation context constrained to zones which allow long term pinning. " },
        { 0x20000000, "PF__HOLE__20000000 — " },
        { 0x40000000, "PF__HOLE__40000000 — " },
        { 0x80000000, "PF_SUSPEND_TASK —  This thread called freeze_processes() and should not be frozen " },
    };

    printf("Анализ флагов (0x%08x):\n", flags);

    unsigned int all = 0;
    int found = 0;
    for (size_t i = 0; i < sizeof(known_flags)/sizeof(*known_flags); i++) {
        all |= known_flags[i].mask;
        if (flags & known_flags[i].mask) {
            printf("  [+] %s\n", known_flags[i].descr);
            found = 1;
        }
    }

    unsigned int unknown = flags & ~all;
    if (unknown) {
        printf("  [?] Неизвестные биты: 0x%08x\n", unknown);
    } else if (!found) {
        printf("  (нет установленных флагов)\n");
    }
}

void analyze_task_state(unsigned int state) {
    struct state_info {
        unsigned int mask;
        const char *description;
    };

    struct state_info known_states[] = {
            { 0x00000000, "TASK_RUNNING" },
            { 0x00000001, "TASK_INTERRUPTIBLE" },
            { 0x00000002, "TASK_UNINTERRUPTIBLE" },
            { 0x00000004, "__TASK_STOPPED" },
            { 0x00000008, "__TASK_TRACED" },
            { 0x00000010, "EXIT_DEAD" },
            { 0x00000020, "EXIT_ZOMBIE" },
            { 0x00000040, "TASK_PARKED" },
            { 0x00000080, "TASK_DEAD" },
            { 0x00000100, "TASK_WAKEKILL" },
            { 0x00000200, "TASK_WAKING" },
            { 0x00000400, "TASK_NOLOAD" },
            { 0x00000800, "TASK_NEW" },
            { 0x00001000, "TASK_RTLOCK_WAIT" },
            { 0x00002000, "TASK_FREEZABLE" },
            { 0x00004000, "__TASK_FREEZABLE_UNSAFE" },
            { 0x00008000, "TASK_FROZEN" },
    };

    struct state_info compound_states[] = {
            { 0x00000030, "EXIT_TRACE (EXIT_ZOMBIE | EXIT_DEAD)" },
            { 0x00000102, "TASK_KILLABLE (TASK_WAKEKILL | TASK_UNINTERRUPTIBLE)" },
            { 0x00000104, "TASK_STOPPED (TASK_WAKEKILL | __TASK_STOPPED)" },
            { 0x00000108, "TASK_TRACED (TASK_WAKEKILL | __TASK_TRACED)" },
            { 0x00000402, "TASK_IDLE (TASK_UNINTERRUPTIBLE | TASK_NOLOAD)" },
            { 0x00000003, "TASK_NORMAL (TASK_INTERRUPTIBLE | TASK_UNINTERRUPTIBLE)" },
    };

    printf("State analysis (0x%08x):\n", state);

    if (state == 0) {
        printf("  [+] TASK_RUNNING\n");
        return;
    }

    for (size_t i = 0; i < sizeof(compound_states) / sizeof(struct state_info); i++) {
        if ((state & compound_states[i].mask) == compound_states[i].mask) {
            printf("  [+] %s\n", compound_states[i].description);
        }
    }

    for (size_t i = 0; i < sizeof(known_states) / sizeof(struct state_info); i++) {
        if (known_states[i].mask == 0) {
            continue;
        }

        if (state & known_states[i].mask) {
            printf("  [+] %s\n", known_states[i].description);
        }
    }

    unsigned int checked_bits = 0;
    for (size_t i = 0; i < sizeof(known_states) / sizeof(struct state_info); i++) {
        checked_bits |= known_states[i].mask;
    }

    unsigned int unknown_bits = state & ~checked_bits;
    if (unknown_bits) {
        printf("  [?] Unknown bits: 0x%08x\n", unknown_bits);
    }
}

int main(int argc, char *argv[])
{
    if (argc < 2) {
        fprintf(stderr, "Использование: %s <маска флагов в hex|dec>\n", argv[0]);
        return 1;
    }

    unsigned int flags = strtoul(argv[1], NULL, 0);

    analyze_task_flags(flags);

    if (argc >= 3) {
        unsigned int state = strtoul(argv[2], NULL, 0);
        printf("\n");
        analyze_task_state(state);
    }

    return 0;
}