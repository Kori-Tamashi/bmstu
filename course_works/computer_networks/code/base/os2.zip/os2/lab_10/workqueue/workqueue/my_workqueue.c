#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/slab.h>
#include <asm/atomic.h>
#include <linux/sched.h>
#include <linux/fs_struct.h>
#include <linux/seq_file.h>
#include <linux/vmalloc.h>
#include <linux/proc_fs.h>
#include <linux/version.h>
#include <linux/time.h>
#include <asm/io.h>
#include <linux/workqueue.h>
#include <linux/delay.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Mikhail Salnikov");

#define IRQ_NUM 1
#define FILE_NAME "key"

typedef struct
{
    struct work_struct work;
    int code;
} key_work_t;

static struct workqueue_struct *key_wq;
static key_work_t *work_im, *work_dl;

static char *key_outs[84] = {
    " ", "Esc", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "=", "Backspace",
    "Tab", "q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "[", "]", "Enter", "Ctrl",
    "a", "s", "d", "f", "g", "h", "j", "k", "l", ";", "'", "`", "Shift (left)", "\\",
    "z", "x", "c", "v", "b", "n", "m", ",", ".", "/", "Shift (right)", "*", "Alt", "Space", "CapsLock",
    "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "NumLock", "ScrollLock",
    "Home", "Up", "Page-Up", "-", "Left", "+", "Right", "End", "Page-Down", "Down", "Insert", "Delete"};

static struct proc_dir_entry *proc_file;

static int code_out = -1;
static char *key_out;
static int shift_pressed = 0;
static char upper_buffer[2];

static int my_show(struct seq_file *m, void *v)
{
    if (code_out != -1)
        seq_printf(m, "Key: %s Code: %d\n", key_out, code_out);
    return 0;
}

static int my_open(struct inode *inode, struct file *file)
{
    return single_open(file, my_show, NULL);
}

static struct proc_ops key_fops = {
    .proc_read = seq_read,
    .proc_open = my_open,
    .proc_release = single_release};

static void wq_immediate(struct work_struct *work)
{
    key_work_t *key_work = (key_work_t *)work;
    int code = key_work->code;
    int is_release = (code & 0x80) ? 1 : 0;
    int press_code = code & 0x7F;

    if (press_code == 42 || press_code == 54) {
        shift_pressed = !is_release;
        return;
    }

    if (is_release && press_code < 84 && press_code != 28)
    {
        code_out = press_code;
        key_out = key_outs[press_code];

        if (shift_pressed && press_code >= 16 && press_code <= 41) {
            upper_buffer[0] = key_out[0] - 32;
            upper_buffer[1] = '\0';
            key_out = upper_buffer;
        }

        printk(KERN_INFO "immedit: Key: %s Code: %d\n", key_out, code_out);
    }
}

static void wq_delayed(struct work_struct *work)
{
    key_work_t *key_work = (key_work_t *)work;
    int code = key_work->code;
    int is_release = (code & 0x80) ? 1 : 0;
    int press_code = code & 0x7F;

    if (press_code == 42 || press_code == 54) {
        shift_pressed = !is_release;
        return;
    }

    if (is_release && press_code < 84 && press_code != 28)
    {
        code_out = press_code;
        key_out = key_outs[press_code];

        if (shift_pressed && press_code >= 16 && press_code <= 41) {
            upper_buffer[0] = key_out[0] - 32;
            upper_buffer[1] = '\0';
            key_out = upper_buffer;
        }

        printk(KERN_INFO "delayed: Key: %s Code: %d\n", key_out, code_out);
    }
    msleep(100);
}

static irqreturn_t my_handler(int irq, void *dev_id)
{
    if (irq == IRQ_NUM)
    {
        int code = inb(0x60);

        work_im->code = code;
        work_dl->code = code;

        queue_work(key_wq, (struct work_struct *)work_im);
        queue_work(key_wq, (struct work_struct *)work_dl);

        return IRQ_HANDLED;
    }
    return IRQ_NONE;
}

static int __init my_init(void)
{
    int ret = request_irq(IRQ_NUM, my_handler, IRQF_SHARED, "my_workqueue_handler", (void *)(my_irq_handler));
    if (ret)
    {
        printk(KERN_ERR "Error: request_irq: %d\n", ret);
        return ret;
    }

    key_wq = alloc_workqueue("my_workqueue", 0, 1);
    if (!key_wq)
    {
        free_irq(IRQ_NUM, (void *)(my_irq_handler));
        printk(KERN_ERR "Error: alloc_workqueue\n");
        return -ENOMEM;
    }

    work_im = (key_work_t *)kmalloc(sizeof(key_work_t), GFP_KERNEL);
    if (!work_im)
    {
        free_irq(IRQ_NUM, (void *)(my_irq_handler));
        destroy_workqueue(key_wq);
        printk(KERN_ERR "Error: kmalloc work_im\n");
        return -ENOMEM;
    }
    INIT_WORK((struct work_struct *)work_im, wq_immediate);

    work_dl = (key_work_t *)kmalloc(sizeof(key_work_t), GFP_KERNEL);
    if (!work_dl)
    {
        free_irq(IRQ_NUM, (void *)(my_irq_handler));
        destroy_workqueue(key_wq);
        kfree(work_im);
        printk(KERN_ERR "Error: kmalloc work_dl\n");
        return -ENOMEM;
    }
    INIT_WORK((struct work_struct *)work_dl, wq_delayed);

    proc_file = proc_create(FILE_NAME, 0444, NULL, &key_fops);
    if (!proc_file)
    {
        printk(KERN_ERR "Error: proc_create\n");
        free_irq(IRQ_NUM, (void *)(my_irq_handler));
        destroy_workqueue(key_wq);
        kfree(work_im);
        kfree(work_dl);
        return -ENOMEM;
    }

    printk(KERN_INFO "loaded\n");
    return 0;
}

static void __exit my_exit(void)
{
    proc_remove(proc_file);

    flush_workqueue(key_wq);
    destroy_workqueue(key_wq);

    free_irq(IRQ_NUM, (void *)(my_irq_handler));

    kfree(work_im);
    kfree(work_dl);

    printk(KERN_INFO "release\n");
}

module_init(my_init);
module_exit(my_exit);