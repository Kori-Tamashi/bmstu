#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define EXIT_FAILURE 1
#define SOCK_NAME "socket.s"
#define BUFFER_SIZE 248

int main()
{
    struct sockaddr sockaddr;
    int sock_fd = socket(AF_UNIX, SOCK_DGRAM, 0);
    if (sock_fd < 0)
    {
        perror("Can't socket");
        exit(EXIT_FAILURE);
    }

    sockaddr = (struct sockaddr){.sa_family = AF_UNIX};
    strcpy(sockaddr.sa_data, SOCK_NAME);

    char buf[BUFFER_SIZE];
    sprintf(buf, "Message from client (PID = %d)", getpid());

    if (sendto(sock_fd, buf, strlen(buf) + 1, 0, &sockaddr, sizeof(sockaddr)) == -1)
    {
        perror("Can't sendto");
        exit(EXIT_FAILURE);
    }

    printf("Client (PID = %d)\tsend:   \t%s\n", getpid(), buf);

    close(sock_fd);

    return 0;
}