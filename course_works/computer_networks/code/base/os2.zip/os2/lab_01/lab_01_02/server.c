#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

#define EXIT_FAILURE 1
#define SOCK_NAME "socket.s"
#define BUFFER_SIZE 248
#define TIME 30

int sock_fd;
char buf[BUFFER_SIZE];

void sigint_handler()
{
    close(sock_fd);
    unlink(SOCK_NAME);
    printf("Alarm expected. Server shutdown...\n");
    exit(0);
}

int main() 
{
    sock_fd = socket(AF_UNIX, SOCK_DGRAM, 0);
    if (sock_fd < 0)
    {
        perror("Can't socket");
        exit(EXIT_FAILURE);
    }

    struct sockaddr sockaddr = {.sa_family = AF_UNIX};
    strcpy(sockaddr.sa_data, SOCK_NAME);

    if (bind(sock_fd, &sockaddr, sizeof(sockaddr)) == -1)
    {
        perror("Can't bind");
        exit(EXIT_FAILURE);
    }

    if (signal(SIGALRM, sigint_handler) == (void *)-1)
    {
        perror("Can't signal");
        exit(EXIT_FAILURE);
    }

    if (alarm(TIME) < 0)
    {
        printf("Can't alarm");
        exit(EXIT_FAILURE);
    }

    while(1)
    {
        int bytes_read = recvfrom(sock_fd, buf, BUFFER_SIZE, 0, NULL, NULL);

        if (bytes_read == -1) 
        {
            perror("Can't read()");
            exit(1);
        }    
        else
        {
            buf[bytes_read] = '\0';
            printf("Server (PID = %d)\trecieve:\t%s\n", getpid(), buf);
        }

        sleep(1);
    }

    alarm(0);
    return 0;
}
