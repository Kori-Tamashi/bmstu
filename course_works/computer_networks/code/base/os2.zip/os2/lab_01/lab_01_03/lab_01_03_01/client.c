#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define SOCK_NAME "socket.socket"
#define BUFFER_SIZE 248

int main()
{
    int sock_fd = socket(AF_UNIX, SOCK_DGRAM, 0);
    if (sock_fd < 0)
    {
        perror("Can't socket");\
        exit(1);
    }

    struct sockaddr server_sockaddr = {.sa_family = AF_UNIX};
    strcpy(server_sockaddr.sa_data, SOCK_NAME);
    int server_addrlen = sizeof(server_sockaddr);

    struct sockaddr client_sockaddr = {.sa_family = AF_UNIX};
    sprintf(client_sockaddr.sa_data, "%d.socket", getpid());

    if (bind(sock_fd, &client_sockaddr, sizeof(client_sockaddr)) == -1)
    {
        perror("Can't bind");
        exit(1);
    }

    char buf[BUFFER_SIZE];
    sprintf(buf, "Message from client (PID = %d)", getpid());

    if (sendto(sock_fd, buf, strlen(buf) + 1, 0, &server_sockaddr, sizeof(server_sockaddr)) == -1)
    {
        perror("Can't sendto");
        exit(1);
    }

    printf("Client (PID = %d)\tsend:   \t%s\n", getpid(), buf);

    int bytes_read = recvfrom(sock_fd, buf, BUFFER_SIZE, 0, &server_sockaddr, &server_addrlen);

    if (bytes_read == -1) 
    {
        perror("Can't read()");
        exit(1);
    }    
    else
    {
        buf[bytes_read] = '\0';
        printf("Client (PID = %d)\trecieve:\t%s\n", getpid(), buf);
    }

    close(sock_fd);
    unlink(client_sockaddr.sa_data);

    return 0;
}