#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <stdio.h>
#include <math.h>
#include <unistd.h>
#include <signal.h>

#define EXIT_FAILURE 1
#define SERVERPATH "serv.socket"

struct request
{
    double a, b;
    char op;
};

static int sock_fd;

void sig_handler(int sig)
{
    close(sock_fd);
    unlink(SERVERPATH);
    printf("Signal %d recieved\n", sig);
    exit(0);
}

int main()
{
    signal(SIGINT, sig_handler);

    double result;
    struct request req;
    socklen_t client_len;
    struct sockaddr server_addr, client_addr;

    sock_fd = socket(AF_UNIX, SOCK_DGRAM, 0);
    if (sock_fd == -1)
    {
        perror("socket error\n");
        exit(EXIT_FAILURE);
    }

    server_addr.sa_family = AF_UNIX;
    strncpy(server_addr.sa_data, SERVERPATH, sizeof(server_addr.sa_data) - 1);

    if (bind(sock_fd, (struct sockaddr *) &server_addr, sizeof(server_addr)) == -1)
    {
        perror("bind error\n");
        close(sock_fd);
        exit(EXIT_FAILURE);
    }

    while (1)
    {
        client_len = sizeof(client_addr);
        ssize_t bytes_recieved = recvfrom(sock_fd, &req, sizeof(req), 0,
                                          (struct sockaddr *) &client_addr, &client_len);
        if (bytes_recieved > 0)
        {
            printf("Server (PID = %d)\trecieved:\t%lf %c %lf\n", getpid(), req.a, req.op, req.b);
            switch (req.op)
            {
                case '+':
                    result = req.a + req.b;
                    break;
                case '-':
                    result = req.a - req.b;
                    break;
                case '*':
                    result = req.a * req.b;
                    break;
                case '/':
                    if (req.b == 0)
                        result = NAN;
                    else
                        result = req.a / req.b;
                    break;
            }

            if (sendto(sock_fd, &result, sizeof(result), 0, (struct sockaddr *) &client_addr, client_len) == -1)
            {
                perror("send error\n");
            } 
            else
            {
                printf("Server (PID = %d)\tsend:    \t%lf\n", getpid(), result);
            }
        } 
        else if (bytes_recieved == -1)
        {
            perror("receive error\n");
        }
    }

    return 0;
}

