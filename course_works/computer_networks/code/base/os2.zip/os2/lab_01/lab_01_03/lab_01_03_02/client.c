#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <math.h>

#define EXIT_FAILURE 1

#define SERVERPATH "serv.socket"

struct request
{
    double a, b;
    char op;
};

static int sock_fd;
static char client_path[14];
const char operation[4] = {'+', '-', '/', '*'};

void sig_handler(int sig_num)
{
    close(sock_fd);
    unlink(client_path);
    printf("Signal %d recieved\n", sig_num);
    exit(0);
}

int main()
{
    srand(getpid());
    signal(SIGINT, sig_handler);

    struct sockaddr server_addr, client_addr;
    struct request req;
    double result;

    sock_fd = socket(AF_UNIX, SOCK_DGRAM, 0);
    if (sock_fd == -1)
    {
        perror("sock error\n");
        exit(EXIT_FAILURE);
    }

    sprintf(client_path, "%d.sock", getpid());

    client_addr.sa_family = AF_UNIX;
    strncpy(client_addr.sa_data, client_path, sizeof(client_addr.sa_data) - 1);

    server_addr.sa_family = AF_UNIX;
    strncpy(server_addr.sa_data, SERVERPATH, sizeof(server_addr.sa_data) - 1);

    if (bind(sock_fd, (struct sockaddr *) &client_addr, sizeof(client_addr)) == -1)
    {
        perror("bind error\n");
        close(sock_fd);
        unlink(client_path);
    }

    while (1)
    {
        req.a = rand() % 100;
        req.b = rand() % 100;
        req.op = operation[rand() % 4];

        if (sendto(sock_fd, &req, sizeof(req), 0, (struct sockaddr *) &server_addr, sizeof(server_addr)) == -1)
        {
            perror("send error\n");
            close(sock_fd);
            unlink(client_path);
            exit(EXIT_FAILURE);
        }

        printf("Client (PID = %d)\tsend:    \t%lf %c %lf\n", getpid(), req.a, req.op, req.b);

        socklen_t server_len = sizeof(server_addr);
        ssize_t bytes_recieved = recvfrom(sock_fd, &result, sizeof(result), 0, (struct sockaddr *) &server_addr,
                                          &server_len);

        if (bytes_recieved > 0)
        {
            if (isnan(result))
                printf("Client (PID = %d)\trecieved:\tError (division by zero)\n", getpid());
            else
                printf("Client (PID = %d)\trecieved:\t%lf\n", getpid(), result);
        }
        sleep(4);
    }

    return 0;
}
