#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

#define SOCK_NAME "socket.socket"
#define BUFFER_SIZE 248
#define TIME 20

int sock_fd;
char buf[BUFFER_SIZE];

void sigint_handler()
{
    close(sock_fd);
    unlink(SOCK_NAME);
    printf("Alarm expected. Server shutdown...\n");
    exit(0);
}

int main() 
{
    sock_fd = socket(AF_UNIX, SOCK_DGRAM, 0);
    if (sock_fd < 0)
    {
        perror("Can't socket");
        exit(1);
    }

    struct sockaddr server_sockaddr = {.sa_family = AF_UNIX};
    strcpy(server_sockaddr.sa_data, SOCK_NAME);

    struct sockaddr client_sockaddr;
    int client_addrlen = sizeof(client_sockaddr);

    if (bind(sock_fd, &server_sockaddr, sizeof(server_sockaddr)) == -1)
    {
        perror("Can't bind");
        exit(1);
    }

    if (signal(SIGALRM, sigint_handler) == (void *)-1)
    {
        perror("Can't signal");
        exit(1);
    }

    if (alarm(TIME) < 0)
    {
        printf("Can't alarm");
        exit(1);
    }

    while(1)
    {
        int bytes_read = recvfrom(sock_fd, buf, BUFFER_SIZE, 0, &client_sockaddr, &client_addrlen);

        if (bytes_read == -1) 
        {
            perror("Can't read()");
            exit(1);
        }    
        else
        {
            buf[bytes_read] = '\0';
            printf("Server (PID = %d)\trecieve:\t%s\n", getpid(), buf);

            sprintf(buf, "Answer from server (PID = %d)", getpid());

            if (sendto(sock_fd, buf, strlen(buf) + 1, 0, &client_sockaddr, client_addrlen) == -1)
            {
                perror("Can't sendto");
                exit(1);
            }
            else
            {
                printf("Server (PID = %d)\tsend:   \t%s\n", getpid(), buf);
            }
        }

        sleep(1);
    }

    alarm(0);
    return 0;
}
