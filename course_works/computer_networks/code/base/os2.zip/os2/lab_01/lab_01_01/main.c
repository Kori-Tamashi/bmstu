#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>

#define STR1 "aaaaaaaaaaaaaaaaaaaaaa"
#define STR2 "bbbb"

#define BUF_SIZE 1024


int main(int arg, char **argv)
{
    int sock_fd[2];
    char buf[BUF_SIZE];

    int pid;
    if (socketpair(AF_UNIX, SOCK_STREAM, 0, sock_fd) < 0) 
    {
        perror("socketpair failed");
        return EXIT_FAILURE;
    }

    pid = fork();
    if (pid != 0)
    {
        close(sock_fd[1]);
        write (sock_fd[0], STR1, sizeof(STR1));
        printf("Parent (PID = %d)\tsend:   \t%s\n", getpid(), STR1);
        read(sock_fd[0], buf, sizeof(buf));
        printf("Parent (PID = %d)\trecieve:\t%s\n", getpid(), buf);
        close(sock_fd[0]);
    }
    else
    {
        close(sock_fd[0]);
        read(sock_fd[1], buf, sizeof(buf));
        printf("Child (PID = %d)\trecieve:\t%s\n", getpid(), buf);
        write(sock_fd[1], STR2, sizeof(STR2));
        printf("Child (PID = %d)\tsend:   \t%s\n", getpid(), STR2);
        close(sock_fd[1]);
    }
}