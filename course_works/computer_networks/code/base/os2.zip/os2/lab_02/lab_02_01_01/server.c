#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <signal.h>
#include <sys/sem.h>
#include <errno.h>
#include <sys/shm.h>
#include <fcntl.h>

#define SERVER_IP "127.0.0.1"
#define SERVER_PORT 8080


#define ACTIVE_READER 0
#define ACTIVE_WRITER 1
#define WRITE_QUEUE   2
#define READ_QUEUE    3
#define BIN_SEM       4


struct sembuf start_read[] = {
    {READ_QUEUE,    1, 0},
    {WRITE_QUEUE,   0, 0},
    {ACTIVE_WRITER, 0, 0},
    {ACTIVE_READER, 1, 0},
    {READ_QUEUE,   -1, 0}
};

struct sembuf stop_read[] = {{ACTIVE_READER, -1, 0}};

struct sembuf start_write[] = {
    {WRITE_QUEUE,   1, 0},
    {ACTIVE_READER, 0, 0},
    {BIN_SEM,      -1, 0},
    {ACTIVE_WRITER, 1, 0},
    {WRITE_QUEUE,  -1, 0}
};

struct sembuf stop_write[] = {
    {ACTIVE_WRITER, -1, 0},
    {BIN_SEM,        1, 0}
};


int sh_fd;
int sem_id;
int sock_fd;
char *seats;
int full_flag = 0;

int main()
{
    signal(SIGINT, handler);

    key_t shmkey = ftok("server", 1);
    if (shmkey == (key_t) -1)
    {
        perror("ftok (shmkey)\n");
        exit(1);
    }

    int perms = S_IRWXU | S_IRWXG | S_IRWXO;
    sh_fd = shmget(shmkey, sizeof(int), perms | IPC_CREAT);
    if (sh_fd == -1)
    {
        perror("shmget");
        exit(1);
    }

    seats = shmat(sh_fd, 0, 0);
    if (seats == (void *) -1)
    {
        perror("shmat");
        exit(1);
    }

    for (int i = 0; i < 26; ++i)
    {
        seats[i] = 'a' + i;
    }

    key_t semkey = ftok("server", 1);
    if (semkey == (key_t) -1)
    {
        perror("ftok (semkey)\n");
        exit(1);
    }

    sem_id = semget(semkey, 5, perms | IPC_CREAT);
    if (sem_id == -1)
    {
        perror("semget");
        exit(1);
    }

    semctl(sem_id, ACTIVE_READER, SETVAL, 0);
    semctl(sem_id, ACTIVE_WRITER, SETVAL, 0);
    semctl(sem_id, WRITE_QUEUE, SETVAL, 0);
    semctl(sem_id, READ_QUEUE, SETVAL, 0);
    semctl(sem_id, BIN_SEM, SETVAL, 1);

    int new_socket;
    char buffer[10] = {};

    if ((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0)
    {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    struct sockaddr_in address;
    int addrlen = sizeof(address);

    address.sin_family = AF_INET;
    address.sin_port = htons(SERVER_PORT);
    address.sin_addr.s_addr = INADDR_ANY;

    if (bind(sock_fd, (struct sockaddr *) &address, sizeof(address)) < 0)
    {
        perror("Bind failed");
        close(sock_fd);
        exit(EXIT_FAILURE);
    }

    if (listen(sock_fd, 3) < 0)
    {
        perror("Listen failed");
        close(sock_fd);
        exit(EXIT_FAILURE);
    }

    printf("Server is listening on %s:%d\n", SERVER_IP, SERVER_PORT);

    while (1)
    {
        if ((new_socket = accept(sock_fd, (struct sockaddr *) &address, (socklen_t *) &addrlen)) < 0)
        {
            perror("Accept failed");
            close(sock_fd);
            exit(EXIT_FAILURE);
        }

        pid_t pid = fork();

        if (pid == -1)
        {
            perror("fork error");
            exit(1);
        }
        else if (pid == 0)
        {
            while (1)
            {
                memset(buffer, 0, 10);
                int bytes_received = read(new_socket, buffer, sizeof(int));
                if (bytes_received < 0)
                {
                    perror("Read failed");
                    close(new_socket);
                    close(sock_fd);
                    exit(EXIT_FAILURE);
                }

                if (buffer[0] == 'r')
                {
                    reader_run(new_socket);
                } 
                else
                {
                    int pos = *((int *) buffer);
                    writer_run(new_socket, pos);
                    break;
                }
            }
            close(new_socket);
            exit(0);
        } 
        else if (pid >= 0)
        {
            close(new_socket);
            if (full_flag)
                break;
        }
    }
    close(sock_fd);

    return 0;
}

void reader_run(int sock)
{
    if (semop(sem_id, start_read, 5) == -1)
    {
        perror("semop:");
        fprintf(stderr, "%d semop err: %d\n", getpid(), errno);
        exit(1);
    }

    send(sock, seats, 26, 0);

    if (semop(sem_id, stop_read, 1) == -1)
    {
        perror("semop:");
        fprintf(stderr, "%d semop err: %d\n", getpid(), errno);
        exit(1);
    }
}

void writer_run(int sock, int pos)
{
    if (semop(sem_id, start_write, 5) == -1)
    {
        perror("semop:");
        fprintf(stderr, "%d semop err: %d\n", getpid(), errno);
        exit(1);
    }

    if (seats[pos] != ' ')
    {
        printf("Position %d char:\t%c\n", pos, seats[pos]);
        send(sock, seats + pos, 1, 0);
        seats[pos] = ' ';
    } 
    else
    {
        char ans = 'n';
        send(sock, &ans, 1, 0);
    }

    if (semop(sem_id, stop_write, 2) == -1)
    {
        perror("semop:");
        fprintf(stderr, "%d semop err: %d\n", getpid(), errno);
        exit(1);
    }

    if (pos == 25)
    {
        close(sock);
        exit(0);
    }
}

void handler(int sig_num)
{
    close(sock_fd);
    printf("received %d", sig_num);

    if (shmdt(seats) == -1)
    {
        perror("shmdt\n");
        exit(1);
    }

    if (shmctl(sh_fd, IPC_RMID, 0) == -1)
    {
        perror("shmctl\n");
        exit(1);
    }

    if (semctl(sem_id, IPC_RMID, 0) == -1)
    {
        perror("semctl\n");
        exit(1);
    }

    exit(0);
}