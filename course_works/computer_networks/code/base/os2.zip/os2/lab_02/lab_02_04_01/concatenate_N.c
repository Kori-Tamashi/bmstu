#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_VALUES 20
#define MAX_LINE_LENGTH 100

int read_first_40_values(const char *filename, int *values)
{
    FILE *file = fopen(filename, "r");
    if (file == NULL)
    {
        perror("Ошибка открытия файла");
        return -1;
    }

    char line[MAX_LINE_LENGTH];
    int count = 0;

    while (fgets(line, sizeof(line), file) && count < MAX_VALUES)
    {
        values[count] = atoi(line);
        count++;
    }

    fclose(file);
    return count;
}

int main() {
    const char *output_file = "result.txt";
    FILE *output = fopen(output_file, "w");
    if (output == NULL) {
        perror("Ошибка открытия файла для записи");
        return 1;
    }
    fprintf(output, "     client_t     server_t  client_m_10  server_m_10   client_m_N   server_m_N\n");

    const char *client_log_t = "client_thread_log.txt";
    const char *server_log_t = "thread_server_log.txt";
    const char *client_log_m = "client_multiplex_log.txt";
    const char *server_log_m = "multiplex_server_log.txt";
    const char *client_log_mN = "client_multiplexN_log.txt";
    const char *server_log_mN = "multiplexN_server_log.txt";
    
    
    int values_t[MAX_VALUES];
    int values_st[MAX_VALUES];
    int values_m[MAX_VALUES];
    int values_sm[MAX_VALUES];
    int values_mN[MAX_VALUES];
    int values_smN[MAX_VALUES];

    
    int count_t = read_first_40_values(client_log_t, values_t);
    int count_st = read_first_40_values(server_log_t, values_st);
    int count_m = read_first_40_values(client_log_m, values_m);
    int count_sm = read_first_40_values(server_log_m, values_sm);
    int count_mN = read_first_40_values(client_log_mN, values_mN);
    int count_smN = read_first_40_values(server_log_mN, values_smN);

    if (count_t == -1 || count_st == -1 || count_m == -1 || count_sm == -1 || count_mN == -1 || count_smN == -1) {
        perror("Ошибка при чтении файлов\n");
        return 1;
    }

    char result[1000] = ""; 
    char temp[100];
    int result_length = 0;

    for (int i = 0; i < MAX_VALUES; i++) {
        sprintf(temp, "%11d %12d %12d %12d %12d %12d\n", values_t[i],values_st[i], values_m[i],  values_sm[i], values_mN[i],  values_smN[i]);
        int temp_length = strlen(temp);
        strcat(result, temp);
        result_length += temp_length;
    }


    if (strlen(result) > 0) {
        result[strlen(result) - 1] = '\0';
    }

    // FILE *output = fopen(output_file, "a");
    // if (output == NULL) {
    //     perror("Ошибка открытия файла для записи");
    //     return 1;
    // }

    fprintf(output, "%s\n", result);
    fclose(output);

    printf("Результат записан в файл %s\n", output_file);

    return 0;
}