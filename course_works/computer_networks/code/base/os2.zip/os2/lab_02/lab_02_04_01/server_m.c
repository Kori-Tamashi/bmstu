#include <arpa/inet.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/epoll.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

#define BUFSIZE 27
#define PORT 1367
#define MAX_EVENTS 10
#define SERVER_LOG_FILE "multiplex_server_log.txt"
#define NUMBER_OF_CONN 300

clock_t end_time;
void refill_buffer(char *sh_string)
{
    for (int i = 0; i < BUFSIZE - 1; i++)
    {
        sh_string[i] = 'A' + i;
    }
    sh_string[BUFSIZE - 1] = '\0';
}

void reader(int con_fd, char *sh_string)
{
    if (send(con_fd, sh_string, BUFSIZE, 0) == -1)
    {
        perror("send");
        exit(EXIT_FAILURE);
    }
}

void log_server_time(clock_t start_time, clock_t end_time)
{
    int elapsed_time = (int)(end_time - start_time);
    FILE *log_file = fopen(SERVER_LOG_FILE, "a");
    if (log_file == NULL)
    {
        perror("fopen");
        return;
    }
    fprintf(log_file, "%d\n", elapsed_time);
    fclose(log_file);
}

void writer(int con_fd, char *sh_string, char letter)
{
    char *pos = strchr(sh_string, letter);
    if (pos != NULL && *pos == letter)
    {
        *pos = '_';

        int empty = 1;
        for (int i = 0; i < BUFSIZE - 1; i++)
        {
            if (sh_string[i] != '_')
            {
                empty = 0;
                break;
            }
        }

        if (empty)
        {
            refill_buffer(sh_string);
        }

        if (send(con_fd, sh_string, BUFSIZE, 0) == -1)
        {
            perror("send");
            exit(EXIT_FAILURE);
        }
    }
    else
    {
        if (send(con_fd, "busy\0", 5, 0) == -1)
        {
            perror("send");
            exit(EXIT_FAILURE);
        }
    }
}

void setnonblocking(int sockfd)
{
    int flags = fcntl(sockfd, F_GETFL, 0);
    if (flags == -1)
    {
        perror("fcntl F_GETFL");
        exit(EXIT_FAILURE);
    }
    if (fcntl(sockfd, F_SETFL, flags | O_NONBLOCK) == -1)
    {
        perror("fcntl F_SETFL");
        exit(EXIT_FAILURE);
    }
}

void service(int client_fd, char* sh_string, clock_t start_time) {
    char request[BUFSIZE + 1] = { 0 };
    ssize_t bytes_read = recv(client_fd, request, BUFSIZE, 0);

    if (bytes_read <= 0) {
        printf("Client disconnected.\n\n");
        close(client_fd);
    }
    else {
        if (*request == 'r') {
            printf("Client: read\n");
            reader(client_fd, sh_string);
        }
        else if (strlen(request) == 1) {
            printf("Client: write %c\n", request[0]);
            writer(client_fd, sh_string, request[0]);
        }
    }
    end_time = clock();
    log_server_time(start_time, end_time);
}

int connection_count = 0;
int main()
{
    int listen_fd, conn_fd;
    struct sockaddr_in address;
    int addrlen = sizeof(address);
    clock_t start_time;

    struct epoll_event ev, events[MAX_EVENTS];
    int nfds, epollfd;

    char sh_string[BUFSIZE + 1];
    refill_buffer(sh_string);

    if ((listen_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        perror("socket");
        close(listen_fd);
        exit(EXIT_FAILURE);
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_ANY);
    address.sin_port = htons(PORT);

    if (bind(listen_fd, (struct sockaddr *)&address, sizeof(address)) == -1)
    {
        perror("bind");
        close(listen_fd);
        exit(EXIT_FAILURE);
    }

    if (listen(listen_fd, 3) == -1)
    {
        perror("listen");
        close(listen_fd);
        exit(EXIT_FAILURE);
    }

    epollfd = epoll_create1(0);
    if (epollfd == -1)
    {
        perror("epoll_create1");
        close(listen_fd);
        exit(EXIT_FAILURE);
    }

    ev.events = EPOLLIN;
    ev.data.fd = listen_fd;
    if (epoll_ctl(epollfd, EPOLL_CTL_ADD, listen_fd, &ev) == -1)
    {
        perror("epoll_ctl: listen_sock");
        close(listen_fd);
        exit(EXIT_FAILURE);
    }

    while (connection_count < NUMBER_OF_CONN)
    {
        printf("NUMBER OF CONN: %d\n", connection_count);
        if (connection_count >= NUMBER_OF_CONN)
        {
            printf("Reached maximum connection limit (300). Server shutting down.\n");
            break;
        }
        nfds = epoll_wait(epollfd, events, MAX_EVENTS, -1);
        if (nfds == -1)
        {
            perror("epoll_wait");
            close(listen_fd);
            exit(EXIT_FAILURE);
        }

        start_time = clock();
        for (int n = 0; n < nfds; ++n)
        {
            if (events[n].data.fd == listen_fd)
            {
                conn_fd = accept(listen_fd, (struct sockaddr *)&address, (socklen_t *)&addrlen);
                if (conn_fd == -1)
                {
                    perror("accept");
                    close(listen_fd);
                    close(conn_fd);
                    continue;
                }
                connection_count++;
                setnonblocking(conn_fd);

                ev.events = EPOLLIN | EPOLLET;
                ev.data.fd = conn_fd;
                if (epoll_ctl(epollfd, EPOLL_CTL_ADD, conn_fd, &ev) == -1)
                {
                    perror("epoll_ctl: conn_sock");
                    close(conn_fd);
                    continue;
                }
            }
            else
            {
                service(events[n].data.fd, sh_string, start_time);
            }
        }
    }

    close(listen_fd);
    close(epollfd);
    return 0;
}
