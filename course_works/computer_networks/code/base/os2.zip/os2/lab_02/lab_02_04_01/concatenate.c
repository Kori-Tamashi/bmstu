#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_VALUES 900
#define MAX_LINE_LENGTH 100
#define RESULT_BUFFER_SIZE 50000 

int read_values(const char *filename, int *values, int max_values) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        perror("Ошибка открытия файла");
        return -1;
    }

    char line[MAX_LINE_LENGTH];
    int count = 0;

    while (fgets(line, sizeof(line), file) && count < max_values) {
        if (strlen(line) > 1) { 
            values[count] = atoi(line);
            count++;
        }
    }

    fclose(file);
    return count;
}

int main() {
    const char *output_file = "result.txt";
    const char *client_log_t = "client_thread_log.txt";
    const char *server_log_t = "thread_server_log.txt";
    const char *client_log_m = "client_multiplex_log.txt";
    const char *server_log_m = "multiplex_server_log.txt";
    
    int values_t[MAX_VALUES] = {0};
    int values_st[MAX_VALUES] = {0};
    int values_m[MAX_VALUES] = {0};
    int values_sm[MAX_VALUES] = {0};

    int sum_values_t = 0;
    int sum_values_st = 0;
    int sum_values_m = 0;
    int sum_values_sm = 0;

    // Чтение данных из файлов
    int count_t = read_values(client_log_t, values_t, MAX_VALUES);
    int count_st = read_values(server_log_t, values_st, MAX_VALUES);
    int count_m = read_values(client_log_m, values_m, MAX_VALUES);
    int count_sm = read_values(server_log_m, values_sm, MAX_VALUES);

    if (count_t == -1 || count_st == -1 || count_m == -1 || count_sm == -1) {
        fprintf(stderr, "Ошибка при чтении файлов\n");
        return 1;
    }

    int actual_count = count_t;
    if (count_st < actual_count) actual_count = count_st;
    if (count_m < actual_count) actual_count = count_m;
    if (count_sm < actual_count) actual_count = count_sm;

    FILE *output = fopen(output_file, "w");
    if (output == NULL) {
        perror("Ошибка открытия файла для записи");
        return 1;
    }

    fprintf(output, "     client_t     server_t     client_m     server_m\n");

    for (int i = 0; i < actual_count; i++) {
        sum_values_t += values_t[i];
        sum_values_st += values_st[i];
        sum_values_m += values_m[i];
        sum_values_sm += values_sm[i];
        
        fprintf(output, "%11d %12d %12d %12d\n", 
               values_t[i], values_st[i], values_m[i], values_sm[i]);
    }

    if (actual_count > 0) {
        fprintf(output, "\navg:%7d %12d %12d %12d\n", 
               sum_values_t / actual_count, 
               sum_values_st / actual_count,
               sum_values_m / actual_count,
               sum_values_sm / actual_count);
    }

    fclose(output);
    printf("Результат записан в файл %s\n", output_file);
    return 0;
}