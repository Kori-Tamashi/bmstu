#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/epoll.h>
#include <fcntl.h>
#include <time.h>

#define BUFSIZE 27
#define PORT 1361
#define MAX_EVENTS 100

#define SERVER_LOG_FILE "multiplexN_server_log.txt"

void reader(int con_fd, char *sh_string) 
{
    if (send(con_fd, sh_string, BUFSIZE, 0) == -1)
    {
        perror("send");
        exit(EXIT_FAILURE);
    }
}

void log_server_time(clock_t start_time, clock_t end_time) 
{
    int elapsed_time = (int_fast16_t)(end_time - start_time); 
    FILE *log_file = fopen(SERVER_LOG_FILE, "a");
    if (log_file == NULL) 
    {
        perror("fopen");
        return;
    }
    fprintf(log_file, "%d\n", elapsed_time);
    fclose(log_file);
}


void writer(int con_fd, char *sh_string, char letter)
{
    char *pos = strchr(sh_string, letter);
    if (pos != NULL && *pos == letter) 
    {
        *pos = '_'; 
        if (send(con_fd, sh_string, BUFSIZE, 0) == -1)
        {
            perror("send");
            exit(EXIT_FAILURE);
        }
    } 
    else 
    {
        if (strcmp(sh_string, "__________________________") == 0) 
        {
            if (send(con_fd, "fail\0", 5, 0) == -1) 
            {
                perror("send");
                exit(EXIT_FAILURE);
            }
        }
        else
        {
            if (send(con_fd, "busy\0", 5, 0) == -1) 
            {
                perror("send");
                exit(EXIT_FAILURE);
            }
        }
    }
}


void setnonblocking(int sockfd) {
    int flags = fcntl(sockfd, F_GETFL, 0);
    if (flags == -1) 
    {
        perror("fcntl F_GETFL");
        exit(EXIT_FAILURE);
    }
    if (fcntl(sockfd, F_SETFL, flags | O_NONBLOCK) == -1) 
    {
        perror("fcntl F_SETFL");
        exit(EXIT_FAILURE);
    }
}

int main() {
    int listen_fd, conn_fd;
    struct sockaddr_in address;
    int addrlen = sizeof(address);
    clock_t start_time, end_time;
    
    struct epoll_event ev, events[MAX_EVENTS];
    int nfds, epollfd;

    char sh_string[BUFSIZE + 1];
    for (int i = 0; i < BUFSIZE - 1; i++) 
    {
        sh_string[i] = 'A' + i;
    }
    sh_string[BUFSIZE - 1] = '\0';

    if ((listen_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        perror("socket");
        close(listen_fd);
        exit(EXIT_FAILURE);
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_ANY);
    address.sin_port = htons(PORT);

    if (bind(listen_fd, (struct sockaddr *)&address, sizeof(address)) == -1)
    {
        perror("bind");
        close(listen_fd);
        exit(EXIT_FAILURE);
    }

    if (listen(listen_fd, 3) == -1)
    {
        perror("listen");
        close(listen_fd);
        exit(EXIT_FAILURE);
    }

    epollfd = epoll_create1(0);
    if (epollfd == -1) {
        perror("epoll_create1");
        close(listen_fd);
        exit(EXIT_FAILURE);
    }

    ev.events = EPOLLIN;
    ev.data.fd = listen_fd;
    if (epoll_ctl(epollfd, EPOLL_CTL_ADD, listen_fd, &ev) == -1) {
        perror("epoll_ctl: listen_sock");
        close(listen_fd);
        exit(EXIT_FAILURE);
    }

    while (1) 
    {
        nfds = epoll_wait(epollfd, events, MAX_EVENTS, -1);
        if (nfds == -1) {
            perror("epoll_wait");
            close(listen_fd);
            exit(EXIT_FAILURE);
        }

        start_time = clock();
        for (int n = 0; n < nfds; ++n) 
        {
            if (events[n].data.fd == listen_fd) 
            {
                conn_fd = accept(listen_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen);
                if (conn_fd == -1) 
                {
                    perror("accept");
                    close(listen_fd);
                    close(conn_fd);
                    continue;
                }

                setnonblocking(conn_fd);

                ev.events = EPOLLIN | EPOLLET;
                ev.data.fd = conn_fd;
                if (epoll_ctl(epollfd, EPOLL_CTL_ADD, conn_fd, &ev) == -1) 
                {
                    perror("epoll_ctl: conn_sock");
                    close(conn_fd);
                    continue;
                }
            } 
            else 
            {
                int client_fd = events[n].data.fd;
                char request[BUFSIZE + 1] = {0};
                ssize_t bytes_read = recv(client_fd, request, BUFSIZE, 0);

                if (bytes_read <= 0) 
                {
                    printf("Client disconnected.\n\n");
                    close(client_fd);
                } 
                else 
                {
                    if (*request == 'r') 
                    {
                        printf("Client: read\n");
                        reader(client_fd, sh_string);
                    } 
                    else if (strlen(request) == 1) 
                    {
                        printf("Client: write %c\n", request[0]);
                        writer(client_fd, sh_string, request[0]);
                    }
                }

                log_server_time(start_time, clock());
            }
        }
    }

    close(listen_fd);
    close(epollfd);

    return 0;
}