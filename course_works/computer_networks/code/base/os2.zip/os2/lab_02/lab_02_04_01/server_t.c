#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pthread.h>

#define STRINGSIZE 27
#define PORT 1367
#define SERVER_LOG_FILE "thread_server_log.txt"
#define NUMBER_OF_CONN 300

clock_t end_time; 
struct thread_args {
    clock_t start_time;  
    int socket_fd;       
};

void log_server_time(clock_t start_time, clock_t end_time) {
    int elapsed_time = (int)(end_time - start_time); 
    FILE *log_file = fopen(SERVER_LOG_FILE, "a");
    if (log_file == NULL) {
        perror("fopen");
        return;
    }
    fprintf(log_file, "%d\n", elapsed_time);
    fclose(log_file);
}

char letters[STRINGSIZE];
int sem_id;

#define WAITING_READERS 0
#define WAITING_WRITERS 1
#define SHADOW 2
#define ACTIVE_READERS 3
#define BINARY 4

struct sembuf start_read[] = {
    {WAITING_READERS, 1, 0},
    {WAITING_WRITERS, 0, 0},
    {SHADOW, 0, 0},
    {ACTIVE_READERS, 1, 0},
    {WAITING_READERS, -1, 0}
};

struct sembuf stop_read[] = {
    {ACTIVE_READERS, -1, 0}
};

struct sembuf start_write[] = {
    {WAITING_WRITERS, 1, 0},
    {ACTIVE_READERS, 0, 0},
    {BINARY, -1, 0},
    {SHADOW, 1, 0},
    {WAITING_WRITERS, -1, 0}
};

struct sembuf stop_write[] = {
    {BINARY, 1, 0},
    {SHADOW, -1, 0}
};

void refill_buffer() {
    for (int i = 0; i < STRINGSIZE - 1; i++) {
        letters[i] = 'A' + i;
    }
    letters[STRINGSIZE - 1] = '\0';
}

void reader(int connfd, int sem_id) {
    if (semop(sem_id, start_read, 5) == -1) {
        perror("semop start_read");
        exit(EXIT_FAILURE);
    }

    if (send(connfd, letters, STRINGSIZE, 0) == -1) {
        perror("send");
        exit(EXIT_FAILURE);
    }

    if (semop(sem_id, stop_read, 1) == -1) {
        perror("semop stop_read");
        exit(EXIT_FAILURE);
    }
}

void writer(int connfd, int sem_id, char letter) {
    if (semop(sem_id, start_write, 5) == -1) {
        perror("semop start_write");
        exit(EXIT_FAILURE);
    }

    char* pos = strchr(letters, letter);
    if (pos != NULL && *pos == letter) {
        *pos = '_';
        
        int empty = 1;
        for (int i = 0; i < STRINGSIZE - 1; i++) {
            if (letters[i] != '_') {
                empty = 0;
                break;
            }
        }
        
        if (empty) {
            refill_buffer();
        }
        
        if (send(connfd, letters, STRINGSIZE, 0) == -1) {
            perror("send");
            exit(EXIT_FAILURE);
        }
    } else {
        if (send(connfd, "busy\0", 5, 0) == -1) {
            perror("send");
            exit(EXIT_FAILURE);
        }
    }

    if (semop(sem_id, stop_write, 2) == -1) {
        perror("semop stop_write");
        exit(EXIT_FAILURE);
    }
}

void* service(void* arg) {
    struct thread_args *args = (struct thread_args*)arg;
    int connfd = args->socket_fd;
    clock_t start_time = args->start_time;
    free(args);

    printf("New client connected.\n");

    while (1) {
        char string_[STRINGSIZE + 1] = {0};
        ssize_t bytes_read = recv(connfd, string_, STRINGSIZE, 0);
        if (bytes_read <= 0) {
            printf("Client disconnected.\n\n");
            break;
        }

        if (*string_ == 'r') {
            printf("Client reads.\n");
            reader(connfd, sem_id);
        } else if (strlen(string_) == 1) {
            printf("Client wants letter %c.\n", string_[0]);
            writer(connfd, sem_id, string_[0]);
        }
    }
    close(connfd);
    end_time = clock();
    log_server_time(start_time, end_time);
    pthread_exit(NULL);
}

int connection_count = 0;
pthread_mutex_t count_mutex = PTHREAD_MUTEX_INITIALIZER;

int main() {
    int listen_fd, connfd;
    struct sockaddr_in address;
    int addrlen = sizeof(address);
    clock_t start_time;
    clock_t end_time;

    refill_buffer();

    int perms = S_IRWXU | S_IRWXG | S_IRWXO; 
    sem_id = semget(IPC_PRIVATE, 5, IPC_CREAT | perms);
    if (sem_id == -1) {
        perror("semget");
        exit(EXIT_FAILURE);
    }

    if (semctl(sem_id, BINARY, SETVAL, 1) == -1) {
        perror("semctl BINARY");
        exit(EXIT_FAILURE);
    }
    if (semctl(sem_id, ACTIVE_READERS, SETVAL, 0) == -1) {
        perror("semctl ACTIVE_READERS");
        exit(EXIT_FAILURE);
    }
    if (semctl(sem_id, WAITING_WRITERS, SETVAL, 0) == -1) {
        perror("semctl WAITING_WRITERS");
        exit(EXIT_FAILURE);
    }
    if (semctl(sem_id, WAITING_READERS, SETVAL, 0) == -1) {
        perror("semctl WAITING_READERS");
        exit(EXIT_FAILURE);
    }
    if (semctl(sem_id, SHADOW, SETVAL, 0) == -1) {
        perror("semctl SHADOW");
        exit(EXIT_FAILURE);
    }

    if ((listen_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_ANY);
    address.sin_port = htons(PORT);

    if (bind(listen_fd, (struct sockaddr *)&address, sizeof(address)) == -1) {
        perror("bind");
        exit(EXIT_FAILURE);
    }

    if (listen(listen_fd, 3) == -1) {
        perror("listen");
        exit(EXIT_FAILURE);
    }

    while (connection_count < NUMBER_OF_CONN) {
        printf("NUMBER OF CONN: %d\n", connection_count);
        if (connection_count >= NUMBER_OF_CONN) {
        printf("Reached maximum connection limit (300). Server shutting down.\n");
        break;
        }
        struct thread_args *args = malloc(sizeof(struct thread_args));
        if (args == NULL) {
            perror("malloc");
            close(listen_fd);
            exit(EXIT_FAILURE);
        }
        start_time = clock();
        if ((connfd = accept(listen_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen)) == -1) {
            perror("accept");
            close(listen_fd);
            exit(EXIT_FAILURE);
        }
        pthread_mutex_lock(&count_mutex);
        connection_count++;
        pthread_mutex_unlock(&count_mutex);

        args->start_time = start_time;
        args->socket_fd = connfd;

        pthread_t thread;
        pthread_attr_t attr;
        pthread_attr_init(&attr);
    
        if (pthread_create(&thread, &attr, service, args) != 0) {
            perror("pthread_create");
            free(args);
            close(connfd);
            close(listen_fd);
        }

        //log_server_time(start_time, clock());
        pthread_detach(thread);
    }

    semctl(sem_id, 0, IPC_RMID);
    close(listen_fd);
    return 0;
}