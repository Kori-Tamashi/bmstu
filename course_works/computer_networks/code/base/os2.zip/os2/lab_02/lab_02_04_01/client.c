#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <time.h>
#include <sys/file.h>  

#define STRINGSIZE 27
#define PORT 1367
#define IP_CLIENT "127.0.0.1"

clock_t end_time;

void log_client_time(clock_t start_time, clock_t end_time, const char* server_type) 
{
    char log_filename[256];
    snprintf(log_filename, sizeof(log_filename), "client_%s_log.txt", server_type);

    int elapsed_time = (int)(end_time - start_time); 

    FILE *log_file = fopen(log_filename, "a");
    if (log_file == NULL) 
    {
        perror("fopen");
        return;
    }

    int fd = fileno(log_file);
    if (flock(fd, LOCK_EX) == -1) 
    {
        perror("flock");
        fclose(log_file);
        return;
    }

    fprintf(log_file, "%d\n", elapsed_time);

    flock(fd, LOCK_UN);
    fclose(log_file);
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <server_type>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    const char* server_type = argv[1];
    int sock_fd = 0;
    struct sockaddr_in serv_addr;
    char string[STRINGSIZE + 1] = {0};

    clock_t start_time, end_time;

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
    serv_addr.sin_addr.s_addr = inet_addr(IP_CLIENT);

    
    while (1) {        
        if ((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
            perror("socket");
            close(sock_fd);
            exit(EXIT_FAILURE);
        }

        start_time = clock();
        if (connect(sock_fd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
            perror("connect");
            close(sock_fd);
            exit(EXIT_FAILURE);
        }

        char string_[STRINGSIZE + 1] = {0};
        char request = 'r';
        int len = snprintf(string_, STRINGSIZE, "%c", request);
        printf("Client string: %s\n", string_);

        if (send(sock_fd, &string_, strlen(string_), 0) == -1) 
        {
            perror("send");
            close(sock_fd);
            exit(EXIT_FAILURE);
        }

        ssize_t bytes_received = recv(sock_fd, string, STRINGSIZE, 0);
        if (bytes_received == 0) 
        {
            printf("Server closed the connection.\n");
            close(sock_fd);
            exit(EXIT_SUCCESS);
        } 
        else if (bytes_received == -1) 
        {
            perror("recv");
            close(sock_fd);
            exit(EXIT_FAILURE);
        }
        printf("Client string: %s\n", string);

        char available_letters[STRINGSIZE] = {0};
        int available_count = 0;

        for (int i = 0; i < STRINGSIZE; i++) 
        {
            if (string[i] != '_') 
            {
                available_letters[available_count++] = string[i];
            }
        }

        if (available_count == 1) 
        {
            printf("No available letters to reserve\n");
            close(sock_fd);
            exit(EXIT_FAILURE);
        }


        char letter = available_letters[0];
        printf("Client Letter: %c\n", letter);

        if (send(sock_fd, &letter, 1, 0) == -1) 
        {
            perror("send");
            close(sock_fd);
            exit(EXIT_FAILURE);
        }

        bytes_received = recv(sock_fd, string, STRINGSIZE, 0);
        if (bytes_received == 0) 
        {
            printf("Server closed the connection.\n");
            close(sock_fd);    
            exit(EXIT_SUCCESS);
        } 
        else if (bytes_received == -1) 
        {
            perror("recv");
            close(sock_fd);
            exit(EXIT_FAILURE);
        }
        else
        {
            if (strcmp(string, "busy") == 0) 
            {
                printf("Letter %c is busy\n\n", letter);
            } 
            else if (strcmp(string, "fail\0") == 0) 
            {
                printf("Buffer empty\n");
                close(sock_fd);
                exit(EXIT_FAILURE);
            } 
            else
            {
                printf("Result: %s\n\n", string);
            }

            if (strcmp(string, "__________________________") == 0) 
            {
                close(sock_fd);
                exit(EXIT_SUCCESS);
            }
        }
        end_time = clock();
        log_client_time(start_time, end_time, server_type);
        close(sock_fd);
    }
    return 0;
}