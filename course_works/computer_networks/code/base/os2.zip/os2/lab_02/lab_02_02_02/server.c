#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <signal.h>
#include <sys/sem.h>
#include <sys/stat.h>
#include <errno.h>
#include <sys/shm.h>
#include <fcntl.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <sched.h>
#include "consts.h"

#define ACTIVE_READER 0
#define ACTIVE_WRITER 1
#define WRITE_QUEUE   2
#define READ_QUEUE    3
#define BIN_SEM       4

struct sembuf start_read[] = {
    {READ_QUEUE,    1, 0},
    {WRITE_QUEUE,   0, 0},
    {ACTIVE_WRITER, 0, 0},
    {ACTIVE_READER, 1, 0},
    {READ_QUEUE,   -1, 0}
};

struct sembuf stop_read[] = {
    {ACTIVE_READER, -1, 0}
};

struct sembuf start_write[] = {
    {WRITE_QUEUE,   1, 0},
    {ACTIVE_READER, 0, 0},
    {BIN_SEM,      -1, 0},
    {ACTIVE_WRITER, 1, 0},
    {WRITE_QUEUE,  -1, 0}
};

struct sembuf stop_write[] = {
    {ACTIVE_WRITER, -1, 0},
    {BIN_SEM,        1, 0}
};

char str[LETTERS_COUNT];

pthread_t tid;
pthread_attr_t tid_attr;

int sem_id;
int listen_sock;
int conn_sock;
int conn_operation;

int server_addrlen, conn_addrlen;
struct sockaddr_in server_address, conn_address;

void reader_run(int sock_fd);
void writer_run(int sock_fd, int position);
void *service(void *arg);

void sig_handler(int sig_num)
{
    printf("\nSignal %d recieved\n", sig_num);

    if (semctl(sem_id, IPC_RMID, 0) == -1)
    {
        perror("Semctl error\n");
        exit(EXIT_FAILURE);
    }

    exit(EXIT_SUCCESS);
}

int main()
{
    signal(SIGINT, sig_handler);
    
    key_t semkey = ftok(PATHNAME, 1);
    if (semkey == (key_t) -1)
    {
        perror("Ftok error\n");
        exit(EXIT_FAILURE);
    }

    int perms = S_IRWXU | S_IRWXG | S_IRWXO;
    sem_id = semget(semkey, 5, perms | IPC_CREAT);
    if (sem_id == -1)
    {
        perror("Semget error\n");
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < LETTERS_COUNT; i++)
        str[i] = FIRST_LETTER + i;

    semctl(sem_id, ACTIVE_READER, SETVAL, 0);
    semctl(sem_id, ACTIVE_WRITER, SETVAL, 0);
    semctl(sem_id, WRITE_QUEUE, SETVAL, 0);
    semctl(sem_id, READ_QUEUE, SETVAL, 0);
    semctl(sem_id, BIN_SEM, SETVAL, 1);

    if ((listen_sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(SERVER_PORT);
    server_address.sin_addr.s_addr = INADDR_ANY;
    server_addrlen = sizeof(server_address);

    if (bind(listen_sock, (struct sockaddr *) &server_address, server_addrlen) < 0)
    {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }

    if (listen(listen_sock, CONNECTIONS) < 0)
    {
        perror("Listen failed");
        exit(EXIT_FAILURE);
    }

    printf("Server is listening on %s:%d\n", SERVER_IP, SERVER_PORT);

    while (1)
    {
        if ((conn_sock = accept(listen_sock, (struct sockaddr *) &conn_address, (socklen_t *) &conn_addrlen)) < 0)
        {
            perror("Accept failed");
            continue;
        }

        int arg = conn_sock;
        
        if (pthread_attr_init(&tid_attr) != 0)
        {
            perror("Thread attr create failled");
            close(conn_sock);
            continue;
        }

        if (pthread_create(&tid, &tid_attr, service, &arg) != 0)
        {
            perror("Thread create failed");
            close(conn_sock);
            continue;
        }

        if (pthread_attr_destroy(&tid_attr) != 0)
        {
            perror("Thread attr destroy failed");
            close(conn_sock);
            continue;
        }
    }

    close(listen_sock);

    if (semctl(sem_id, IPC_RMID, 0) == -1)
    {
        perror("Semctl error\n");
        exit(EXIT_FAILURE);
    }

    exit(EXIT_SUCCESS);
}

void *service(void *arg)
{
    int conn_sock_fd = *((int *) arg);

    int cpu_id;
    getcpu(&cpu_id, NULL);
    printf("Thread %ld, client %d running on cpu %d\n", pthread_self(), conn_sock_fd, cpu_id);

    while (1) 
    {
        int bytes_received = read(conn_sock_fd, &conn_operation, sizeof(int));
        if (bytes_received < 0)
        {
            perror("Read failed");
            close(conn_sock_fd);
            pthread_exit(EXIT_SUCCESS);
        }

        if (conn_operation == READ_OPERATION)
        {
            reader_run(conn_sock_fd);
        }
        else
        {
            int position = conn_operation;
            writer_run(conn_sock_fd, position);
            break;
        }
    }

    close(conn_sock_fd);
    pthread_exit(EXIT_SUCCESS);
}

void reader_run(int sock_fd)
{
    if (semop(sem_id, start_read, 5) == -1)
    {
        perror("semop:");
        fprintf(stderr, "%d semop err: %d\n", getpid(), errno);
        close(sock_fd);
        pthread_exit(EXIT_FAILURE);
    }

    send(sock_fd, str, LETTERS_COUNT, 0);

    if (semop(sem_id, stop_read, 1) == -1)
    {
        perror("semop:");
        fprintf(stderr, "%d semop err: %d\n", getpid(), errno);
        close(sock_fd);
        pthread_exit(EXIT_FAILURE);
    }
}

void writer_run(int sock_fd, int position)
{
    if (semop(sem_id, start_write, 5) == -1)
    {
        perror("semop:");
        fprintf(stderr, "%d semop err: %d\n", getpid(), errno);
        close(sock_fd);
        pthread_exit(EXIT_FAILURE);
    }

    if (str[position] != ' ')
    {
        printf("Position %d char:\t%c\n", position, str[position]);
        send(sock_fd, str + position, sizeof(char), 0);
        str[position] = ' ';
    } 
    else
    {
        char answer = POSITION_OCCUPIED;
        send(sock_fd, &answer, sizeof(char), 0);
    }

    if (semop(sem_id, stop_write, 2) == -1)
    {
        perror("semop:");
        fprintf(stderr, "%d semop err: %d\n", getpid(), errno);
        close(sock_fd);
        pthread_exit(EXIT_FAILURE);
    }
}
