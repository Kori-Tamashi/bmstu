#ifndef CONSTS_H__
#define CONSTS_H__

#define SERVER_IP "127.0.0.1"
#define SERVER_PORT 8080

#define EXIT_ACCESS 0
#define EXIT_FAILURE 1

#define FIRST_LETTER 'a'
#define LETTERS_COUNT 26
#define READ_OPERATION -1
#define POSITION_OCCUPIED -2

#define PATHNAME "shm_buffer"
#define CONNECTIONS 3

#endif // CONSTS_H__