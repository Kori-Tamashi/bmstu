#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_ENTRIES 1000
#define MAX_LINE_LENGTH 100

typedef struct {
    int client_thread;
    int server_thread;
    int client_epoll;
    int server_epoll;
} TimeRecord;

TimeRecord records[MAX_ENTRIES];
int sums[4] = {0};
int count = 0;

void read_data(const char* filename, int* values, int* count) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        perror("Failed to open file");
        return;
    }

    char line[MAX_LINE_LENGTH];
    *count = 0;
    
    while (fgets(line, sizeof(line), file) && *count < MAX_ENTRIES) {
        values[(*count)++] = atoi(line);
    }
    
    fclose(file);
}

void read_data_multiplex_server(const char* filename, int* values, int* count) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        perror("Failed to open file");
        return;
    }

    char line[MAX_LINE_LENGTH];
    *count = 0;
    
    while (fgets(line, sizeof(line), file) && *count < MAX_ENTRIES) {
        values[(*count)] = atoi(line);
        fgets(line, sizeof(line), file);
        values[(*count)++] += atoi(line);
    }
    
    fclose(file);
}

void write_results(const char* filename) {
    FILE* file = fopen(filename, "w");
    if (!file) {
        perror("Failed to create result file");
        return;
    }

    // Заголовок таблицы
    fprintf(file, "Client Thread | Server Thread | Client Epoll | Server Epoll\n");
    fprintf(file, "----------------------------------------------------------\n");

    // Данные
    for (int i = 0; i < count; i++) {
        fprintf(file, "%13d | %12d | %13d | %12d\n", 
               records[i].client_thread,
               records[i].server_thread,
               records[i].client_epoll,
               records[i].server_epoll);
    }

    fprintf(file, "----------------------------------------------------------\n");

    fprintf(file, "%13d | %12d | %13d | %12d\n", 
            sums[0] / count,
            sums[1] / count,
            sums[2] / count,
            sums[3] / count);

    fclose(file);
    printf("Results saved to %s\n", filename);
}

int main() {
    int client_thread[MAX_ENTRIES], server_thread[MAX_ENTRIES];
    int client_epoll[MAX_ENTRIES], server_epoll[MAX_ENTRIES];
    
    int ct_count, st_count, ce_count, se_count;

    // Чтение данных из всех лог-файлов
    read_data("client_threads_log.txt", client_thread, &ct_count);
    read_data("thread_server_log.txt", server_thread, &st_count);
    read_data("client_multiplex_log.txt", client_epoll, &ce_count);
    read_data("multiplex_server_log.txt", server_epoll, &se_count);

    // Определяем минимальное количество записей
    count = ct_count;
    if (st_count < count) count = st_count;
    if (ce_count < count) count = ce_count;
    if (se_count < count) count = se_count;

    // Формируем записи для таблицы
    for (int i = 0; i < count; i++) {
        records[i].client_thread = client_thread[i];
        records[i].server_thread = server_thread[i];
        records[i].client_epoll = client_epoll[i];
        records[i].server_epoll = server_epoll[i];
    }

    // Подсчет средних значений
    for (int i = 0; i < count; i++)
    {
        sums[0] += records[i].client_thread;
        sums[1] += records[i].server_thread;
        sums[2] += records[i].client_epoll;
        sums[3] += records[i].server_epoll;
    }

    // Сохраняем результаты
    write_results("comparison_results.txt");

    return 0;
}