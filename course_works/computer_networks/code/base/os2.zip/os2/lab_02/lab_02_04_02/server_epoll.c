#include <sys/epoll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <signal.h>
#include <sys/sem.h>
#include <sys/stat.h>
#include <errno.h>
#include <sys/shm.h>
#include <fcntl.h>
#include <pthread.h>
#include <arpa/inet.h>
#include "consts.h"

char buffer[LETTERS_COUNT];
int bytes_recieved;

int epoll_fd;
int listen_sock_fd;
int conn_sock_fd;
int current_conn_sock_fd;
int conn_operation;

int server_addrlen, conn_addrlen;
struct sockaddr_in server_address, conn_address;

int nfds = 0;
struct epoll_event ev, events[MAX_EVENTS];

void reader_run(int sock_fd);
void writer_run(int sock_fd, int position);
void log_server_time(clock_t start_time, clock_t end_time);

void handler(int sig_num)
{
    printf("\nSignal %d recieved\n", sig_num);

    close(listen_sock_fd);

    exit(EXIT_SUCCESS);
}

void setnonblocking(int sockfd)
{
    int flags = fcntl(sockfd, F_GETFL, 0);
    fcntl(sockfd, F_SETFL, flags | O_NONBLOCK);
}

int main(int argc, char *argv[])
{
    signal(SIGINT, handler);

    for (int i = 0; i < LETTERS_COUNT; i++)
        buffer[i] = FIRST_LETTER;

    if ((listen_sock_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(SERVER_PORT);
    server_address.sin_addr.s_addr = INADDR_ANY;
    server_addrlen = sizeof(server_address);

    if (bind(listen_sock_fd, (struct sockaddr *) &server_address, server_addrlen) < 0)
    {
        perror("Bind failed");
        close(listen_sock_fd);
        exit(EXIT_FAILURE);
    }

    if (listen(listen_sock_fd, CONNECTIONS) < 0)
    {
        perror("Listen failed");
        close(listen_sock_fd);
        exit(EXIT_FAILURE);
    }
    else
    {
        printf("Server is listening on %s:%d\n", SERVER_IP, SERVER_PORT);
    }

    epoll_fd = epoll_create1(0);
    if (epoll_fd == -1)
    {
        perror("epoll_create1");
        exit(EXIT_FAILURE);
    }
    
    ev.events = EPOLLIN;
    ev.data.fd = listen_sock_fd;
    if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, listen_sock_fd, &ev) == -1)
    {
        perror("epoll_ctl: listen_sock");
        exit(EXIT_FAILURE);
    }

    while (1)
    {
        nfds = epoll_wait(epoll_fd, events, MAX_EVENTS, -1);
        if (nfds == -1)
        {
            perror("epoll_wait");
            exit(EXIT_FAILURE);
        }

        clock_t start_time = clock();
        for (int n = 0; n < nfds; n++)
        {
            if (events[n].data.fd == listen_sock_fd)
            {
                conn_sock_fd = accept(listen_sock_fd, (struct sockaddr *) &conn_address, (socklen_t *) &conn_addrlen);
                if (conn_sock_fd < 0)
                {
                    perror("accept");
                    exit(EXIT_FAILURE);
                }

                setnonblocking(conn_sock_fd);

                ev.events = EPOLLIN | EPOLLET;
                ev.data.fd = conn_sock_fd;
                if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, conn_sock_fd, &ev) < 0)
                {
                    perror("epoll_ctl: conn_sock");
                    exit(EXIT_FAILURE);
                }
            }
            else
            {
                current_conn_sock_fd = events[n].data.fd;
                bytes_recieved = read(current_conn_sock_fd, &conn_operation, sizeof(int));
                if (bytes_recieved <= 0)
                {
                    close(current_conn_sock_fd);
                    continue;
                }

                if (conn_operation == READ_OPERATION)
                {
                    reader_run(current_conn_sock_fd);
                }
                else
                {
                    int position = conn_operation;
                    writer_run(current_conn_sock_fd, position);
                    
                    clock_t end_time = clock();
                    log_server_time(start_time, end_time);
                }
            }        
        }
    }
}

void reader_run(int sock_fd)
{
    if (send(sock_fd, buffer, LETTERS_COUNT, 0) < 0)
    {
        perror("send");
        exit(EXIT_FAILURE);
    }
}

void writer_run(int sock_fd, int position)
{
    if (buffer[position] != ' ')
    {
        printf("Position %d char:\t%c\n", position, buffer[position]);
        if (send(sock_fd, buffer + position, sizeof(char), 0) < 0)
        {
            perror("send");
            exit(EXIT_FAILURE);
        }
        buffer[position] = ' ';
    } 
    else
    {
        char answer = POSITION_OCCUPIED;
        if (send(sock_fd, &answer, sizeof(char), 0) < 0)
        {
            perror("send");
            exit(EXIT_FAILURE);
        }
    }
}


void log_server_time(clock_t start_time, clock_t end_time) 
{
    char log_filename[256];
    snprintf(log_filename, sizeof(log_filename), "multiplex_server_log.txt");
    
    int elapsed_time = (int)(end_time - start_time);
    
    FILE *log_file = fopen(log_filename, "a");
    if (log_file) {
        fprintf(log_file, "%d\n", elapsed_time);
        fclose(log_file);
    }
}