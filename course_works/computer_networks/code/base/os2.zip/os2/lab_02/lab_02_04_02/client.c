#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>
#include <sys/file.h>
#include <pthread.h>
#include <string.h>
#include "consts.h"

#define THREAD_COUNT 1 // Количество клиентских потоков

char server_type[20];

void handler(int sig_num) {
    printf("\nSignal %d received. Exiting...\n", sig_num);
    exit(EXIT_SUCCESS);
}

void log_client_time(clock_t start_time, clock_t end_time, const char* server_type, int thread_id) {
    char log_filename[256];
    snprintf(log_filename, sizeof(log_filename), "client_%s_log.txt", server_type);
    
    int elapsed_time = (int)(end_time - start_time);
    
    FILE *log_file = fopen(log_filename, "a");
    if (log_file == NULL) {
        perror("fopen");
        return;
    }
    
    fprintf(log_file, "%d\n", elapsed_time);
    fclose(log_file);
}

void* client_thread(void* arg) {
    int thread_id = *((int*)arg);
    
    struct sockaddr_in server_sockaddr;
    server_sockaddr.sin_family = AF_INET;
    server_sockaddr.sin_port = htons(SERVER_PORT);
    server_sockaddr.sin_addr.s_addr = inet_addr(SERVER_IP);
    
    printf("Thread %d started for server type: %s\n", thread_id, server_type);
    
    while (1) {
        clock_t start = clock();
        char buffer[LETTERS_COUNT];
        char answer;
        int position;
        int bytes_received;
        int server_sock_fd;

        // Соединение для чтения буфера
        if ((server_sock_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
            perror("Socket creation error");
            sleep(1);
            continue;
        }

        if (connect(server_sock_fd, (struct sockaddr*)&server_sockaddr, sizeof(server_sockaddr)) < 0) {
            perror("Connection failed");
            close(server_sock_fd);
            sleep(1);
            continue;
        }

        int read_operation = READ_OPERATION;
        if (send(server_sock_fd, &read_operation, sizeof(int), 0) < 0) {
            perror("Send failed (start read)");
            close(server_sock_fd);
            continue;
        }

        bytes_received = read(server_sock_fd, buffer, LETTERS_COUNT);
        if (bytes_received < 0) {
            perror("Read failed");
            continue;
        }

        // Поиск первой свободной позиции
        for (position = 0; position < LETTERS_COUNT && buffer[position] == ' '; position++);

        if (position >= LETTERS_COUNT) {
            printf("Thread %d: Buffer is empty\n", thread_id);
            sleep(1);
            continue;
        }

        if (send(server_sock_fd, &position, sizeof(int), 0) < 0) {
            perror("Send failed (position)");
            close(server_sock_fd);
            continue;
        }

        bytes_received = read(server_sock_fd, &answer, sizeof(char));
        if (bytes_received < 0) {
            perror("Read failed (answer)");
            continue;
        }

        close(server_sock_fd);

        if (answer != POSITION_OCCUPIED) {
            printf("Thread %d: Position %d - %c\n", thread_id, position, answer);
        } else {
            printf("Thread %d: Position %d occupied\n", thread_id, position);
        }
        
        clock_t end = clock();
        log_client_time(start, end, server_type, thread_id);

        // Случайная задержка между 50-150 мс
        usleep(50000 + (rand() % 10000));
    }
    
    return NULL;
}

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <server_type>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    signal(SIGINT, handler);
    srand(time(NULL)); // Инициализация генератора случайных чисел

    pthread_t threads[THREAD_COUNT];
    int thread_args[THREAD_COUNT][2]; // [thread_id, server_type_ptr]

    strcpy(server_type, argv[1]);

    // Создаем потоки
    for (int i = 0; i < THREAD_COUNT; i++) {
        thread_args[i][0] = i; // thread_id
        thread_args[i][1] = argv[1]; 
        
        if (pthread_create(&threads[i], NULL, client_thread, thread_args[i]) != 0) {
            perror("pthread_create");
            exit(EXIT_FAILURE);
        }
    }

    // Ожидаем завершения потоков (никогда не произойдет)
    for (int i = 0; i < THREAD_COUNT; i++) {
        pthread_join(threads[i], NULL);
    }

    return EXIT_SUCCESS;
}