#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <signal.h>
#include "consts.h"

int server_sock_fd = 0;

void handler(int sig_num)
{
    printf("\nSignal %d recieved\n", sig_num);
    close(server_sock_fd);
    exit(EXIT_SUCCESS);
}

int main(int argc, char **argv)
{
    signal(SIGINT, handler);

    char buffer[LETTERS_COUNT];
    const int read_operation = READ_OPERATION;

    struct sockaddr_in server_sockaddr;
    server_sockaddr.sin_family = AF_INET;
    server_sockaddr.sin_port = htons(SERVER_PORT);
    server_sockaddr.sin_addr.s_addr = inet_addr(SERVER_IP);

    while (1)
    {
        char answer = 0;
        int position = 0;
        int bytes_received = 0;

        if ((server_sock_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
        {
            perror("Socket creation error");
            exit(EXIT_FAILURE);
        }

        if (connect(server_sock_fd, (struct sockaddr *) &server_sockaddr, sizeof(server_sockaddr)) < 0)
        {
            perror("Connection failed");
            close(server_sock_fd);
            exit(EXIT_FAILURE);
        }

        if (send(server_sock_fd, &read_operation, sizeof(int), 0) < 0)
        {
            perror("Send failed (start read)");
            close(server_sock_fd);
            exit(EXIT_FAILURE);
        }

        bytes_received = read(server_sock_fd, &buffer, LETTERS_COUNT);
        if (bytes_received < 0)
        {
            perror("Read failed");
            close(server_sock_fd);
            exit(EXIT_FAILURE);
        }

        printf("Buffer:  \t");
        for (int i = 0; i < LETTERS_COUNT; i++)
        {
            if (buffer[i] != ' ')
                printf("%c ", buffer[i]);
            else
                printf("_ ");
        }
        printf("\n");

        for (position = 0; position < LETTERS_COUNT && buffer[position] == ' '; position++);

        if (position < LETTERS_COUNT)
        {
            printf("Position:\t%d\n", position);
            if (send(server_sock_fd, &position, sizeof(int), 0) < 0)
            {
                perror("Send failed");
                close(server_sock_fd);
                exit(EXIT_FAILURE);
            }
        }
        else
        {
            printf("Buffer is empty\n");
            close(server_sock_fd);
            exit(EXIT_FAILURE);
        }

        bytes_received = read(server_sock_fd, &answer, sizeof(char));
        if (bytes_received < 0)
        {
            perror("Read failed");
            close(server_sock_fd);
            exit(EXIT_FAILURE);
        }

        if (answer != POSITION_OCCUPIED)
            printf("Answer:  \t%c\n", answer);
        else
            printf("Answer:  \tCouldn't take a position\n");
        
        close(server_sock_fd);
        sleep(2);
    }

    return EXIT_SUCCESS;
};