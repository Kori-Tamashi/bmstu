#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <signal.h>
#include <sys/sem.h>
#include <errno.h>
#include <sys/shm.h>
#include <fcntl.h>
#include "consts.h"

#define ACTIVE_READER 0
#define ACTIVE_WRITER 1
#define WRITE_QUEUE   2
#define READ_QUEUE    3
#define BIN_SEM       4

typedef short bool;

struct sembuf start_read[] = {
    {READ_QUEUE,    1, 0},
    {WRITE_QUEUE,   0, 0},
    {ACTIVE_WRITER, 0, 0},
    {ACTIVE_READER, 1, 0},
    {READ_QUEUE,   -1, 0}
};

struct sembuf stop_read[] = {
    {ACTIVE_READER, -1, 0}
};

struct sembuf start_write[] = {
    {WRITE_QUEUE,   1, 0},
    {ACTIVE_READER, 0, 0},
    {BIN_SEM,      -1, 0},
    {ACTIVE_WRITER, 1, 0},
    {WRITE_QUEUE,  -1, 0}
};

struct sembuf stop_write[] = {
    {ACTIVE_WRITER, -1, 0},
    {BIN_SEM,        1, 0}
};


pid_t pid = 0;

int perms = 0;
int shm_fd = 0;
int sem_id = 0;
bool is_done = 0;
char *char_array = NULL;

int server_sock_fd = 0;
int client_sock_fd = 0;
int client_operation = 0;

int server_addrlen, client_addrlen;
struct sockaddr_in server_address, client_address;

void reader_run(int sock_fd);
void writer_run(int sock_fd, int position);

void handler(int sig_num)
{
    printf("\nSignal %d recieved\n", sig_num);

    close(server_sock_fd);

    if (shmdt(char_array) == -1)
    {
        perror("Shmdt error\n");
        exit(EXIT_FAILURE);
    }

    if (shmctl(shm_fd, IPC_RMID, 0) == -1)
    {
        perror("Shmctl error\n");
        exit(EXIT_FAILURE);
    }

    if (semctl(sem_id, IPC_RMID, 0) == -1)
    {
        perror("Semctl error\n");
        exit(EXIT_FAILURE);
    }

    exit(EXIT_SUCCESS);
}

int main()
{
    signal(SIGINT, handler);
    signal(SIGCHLD, SIG_IGN);

    key_t shmkey = ftok(PATHNAME, 1);
    if (shmkey == (key_t) -1)
    {
        perror("Ftok error\n");
        exit(EXIT_FAILURE);
    }

    perms = S_IRWXU | S_IRWXG | S_IRWXO;
    shm_fd = shmget(shmkey, sizeof(int), perms | IPC_CREAT);
    if (shm_fd == -1)
    {
        perror("Shmget error\n");
        exit(EXIT_FAILURE);
    }

    char_array = shmat(shm_fd, 0, 0);
    if (char_array == (void *) -1)
    {
        perror("Shmat error\n");
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < LETTERS_COUNT; i++)
        char_array[i] = FIRST_LETTER + i;

    key_t semkey = ftok(PATHNAME, 1);
    if (semkey == (key_t) -1)
    {
        perror("Ftok error\n");
        exit(EXIT_FAILURE);
    }

    sem_id = semget(semkey, 5, perms | IPC_CREAT);
    if (sem_id == -1)
    {
        perror("Semget error\n");
        exit(EXIT_FAILURE);
    }

    semctl(sem_id, ACTIVE_READER, SETVAL, 0);
    semctl(sem_id, ACTIVE_WRITER, SETVAL, 0);
    semctl(sem_id, WRITE_QUEUE, SETVAL, 0);
    semctl(sem_id, READ_QUEUE, SETVAL, 0);
    semctl(sem_id, BIN_SEM, SETVAL, 1);


    if ((server_sock_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(SERVER_PORT);
    server_address.sin_addr.s_addr = INADDR_ANY;
    server_addrlen = sizeof(server_address);

    if (bind(server_sock_fd, (struct sockaddr *) &server_address, server_addrlen) < 0)
    {
        perror("Bind failed");
        close(server_sock_fd);
        exit(EXIT_FAILURE);
    }

    if (listen(server_sock_fd, CONNECTIONS) < 0)
    {
        perror("Listen failed");
        close(server_sock_fd);
        exit(EXIT_FAILURE);
    }

    printf("Server is listening on %s:%d\n", SERVER_IP, SERVER_PORT);

    while (1) 
    {
        if ((client_sock_fd = accept(server_sock_fd, (struct sockaddr *) &client_address, (socklen_t *) &client_addrlen)) < 0)
        {
            perror("Accept failed");
            close(server_sock_fd);
            exit(EXIT_FAILURE);
        }

        if ((pid = fork()) == -1)
        {
            perror("fork error");
            exit(EXIT_FAILURE);
        }
        else if (pid == 0)
        {
            while(1) 
            {
                int bytes_received = read(client_sock_fd, &client_operation, sizeof(int));
                if (bytes_received < 0)
                {
                    perror("Read failed");
                    close(client_sock_fd);
                    close(server_sock_fd);
                    exit(EXIT_FAILURE);
                }

                if (client_operation == READ_OPERATION)
                {
                    reader_run(client_sock_fd);
                }
                else
                {
                    int position = client_operation;
                    writer_run(client_sock_fd, position);
                    break;
                }
            }

            close(client_sock_fd);
            exit(EXIT_SUCCESS);
        }
        else 
        {
            if (is_done)
                break;
        }
    }

    close(server_sock_fd);

    if (shmdt(char_array) == -1)
    {
        perror("Shmdt error\n");
        exit(EXIT_FAILURE);
    }

    if (shmctl(shm_fd, IPC_RMID, 0) == -1)
    {
        perror("Shmctl error\n");
        exit(EXIT_FAILURE);
    }

    if (semctl(sem_id, IPC_RMID, 0) == -1)
    {
        perror("Semctl error\n");
        exit(EXIT_FAILURE);
    }

    return EXIT_SUCCESS;
};

void reader_run(int sock_fd)
{
    if (semop(sem_id, start_read, 5) == -1)
    {
        perror("semop:");
        fprintf(stderr, "%d semop err: %d\n", getpid(), errno);
        exit(EXIT_FAILURE);
    }

    send(sock_fd, char_array, LETTERS_COUNT, 0);

    if (semop(sem_id, stop_read, 1) == -1)
    {
        perror("semop:");
        fprintf(stderr, "%d semop err: %d\n", getpid(), errno);
        exit(EXIT_FAILURE);
    }
}

void writer_run(int sock_fd, int position)
{
    if (semop(sem_id, start_write, 5) == -1)
    {
        perror("semop:");
        fprintf(stderr, "%d semop err: %d\n", getpid(), errno);
        exit(EXIT_FAILURE);
    }

    if (char_array[position] != ' ')
    {
        printf("Position %d char:\t%c\n", position, char_array[position]);
        send(sock_fd, char_array + position, sizeof(char), 0);
        char_array[position] = ' ';
    } 
    else
    {
        char answer = POSITION_OCCUPIED;
        send(sock_fd, &answer, sizeof(char), 0);
    }

    if (semop(sem_id, stop_write, 2) == -1)
    {
        perror("semop:");
        fprintf(stderr, "%d semop err: %d\n", getpid(), errno);
        exit(EXIT_FAILURE);
    }
}