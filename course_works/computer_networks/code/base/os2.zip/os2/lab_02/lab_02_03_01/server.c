#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pthread.h>
#include <sys/sem.h>
#include <sys/epoll.h>
#include <fcntl.h>

#define BUFSIZE 26
#define MAX_QUEUE 3
#define MES_SIZE 10

#define PORT 9051

char buffer[BUFSIZE];

int count_avaliable()
{
    int count = 0;
    for (int i = 0; i < BUFSIZE; i++)
    {
        if (buffer[i] != '_')
            count++;
    }
    return count;
}

void init_buf()
{
    for (int i = 0; i < BUFSIZE; i++)
    {
        buffer[i] = 'a' + i;
    }
}

void client_read(int listen_sockfd)
{
    char res[BUFSIZE + 4];
    int avaliable = count_avaliable();
    sprintf(res, "%2d %s", avaliable, buffer);

    if (send(listen_sockfd, res, BUFSIZE + 3, 0) == -1)
    {
        perror("send");
        exit(EXIT_FAILURE);
    }
}

void client_write(int listen_sockfd, int index)
{
    char res[BUFSIZE + 4];

    if (buffer[index] == '_')
    {
        sprintf(res, "%s", "error: letter not avaliable");
    }
    else
    {
        buffer[index] = '_';
        int avaliable = count_avaliable();
        sprintf(res, "%2d %s", avaliable, buffer);
    }

    if (send(listen_sockfd, res, BUFSIZE + 3, 0) == -1)
    {
        perror("send");
        exit(EXIT_FAILURE);
    }
}
#define MAX_EVENTS 10

void setnonblocking(int sockfd)
{
    int flags = fcntl(sockfd, F_GETFL, 0);
    fcntl(sockfd, F_SETFL, flags | O_NONBLOCK);
}

int main(int argc, char *argv[])
{
    init_buf();

    struct epoll_event ev, events[MAX_EVENTS];
    int listen_sockfd, conn_sock, nfds, epollfd;

    listen_sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (listen_sockfd < 0)
    {
        perror("cant socket");
        exit(EXIT_FAILURE);
    }

    struct sockaddr_in address;
    int addrlen = sizeof(address);

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_ANY);
    address.sin_port = htons(PORT);

    if (bind(listen_sockfd, (struct sockaddr *)&address, sizeof(address)) == -1)
    {
        perror("cant bind");
        close(listen_sockfd);
        exit(EXIT_FAILURE);
    }

    if (listen(listen_sockfd, MAX_QUEUE) == -1)
    {
        perror("cant listen");
        close(listen_sockfd);
        exit(EXIT_FAILURE);
    }

    epollfd = epoll_create1(0);
    if (epollfd == -1)
    {
        perror("epoll_create1");
        exit(EXIT_FAILURE);
    }

    ev.events = EPOLLIN;
    ev.data.fd = listen_sockfd;
    if (epoll_ctl(epollfd, EPOLL_CTL_ADD, listen_sockfd, &ev) == -1)
    {
        perror("epoll_ctl: listen_sock");
        exit(EXIT_FAILURE);
    }

    for (;;)
    {
        nfds = epoll_wait(epollfd, events, MAX_EVENTS, -1);
        if (nfds == -1)
        {
            perror("epoll_wait");
            exit(EXIT_FAILURE);
        }

        clock_t start = clock();
        for (int n = 0; n < nfds; ++n)
        {
            if (events[n].data.fd == listen_sockfd)
            {
                conn_sock = accept(listen_sockfd,
                                   (struct sockaddr *)&address, (socklen_t *)&addrlen);
                if (conn_sock == -1)
                {
                    perror("accept");
                    exit(EXIT_FAILURE);
                }

                setnonblocking(conn_sock);


                ev.events = EPOLLIN | EPOLLET;
                ev.data.fd = conn_sock;
                if (epoll_ctl(epollfd, EPOLL_CTL_ADD, conn_sock,
                              &ev) == -1)
                {
                    perror("epoll_ctl: conn_sock");
                    exit(EXIT_FAILURE);
                }
            }
            else
            {
                char message[MES_SIZE];
                int sock_now = events[n].data.fd;
                ssize_t bytes_read = read(sock_now, message, MES_SIZE);
                if (bytes_read <= 0)
                {
                    printf("Client finished.\n");
                    close(conn_sock);
                    break;
                }
                else
                {
                    if (message[0] == 'r')
                    {
                        printf("client: read request\n");
                        client_read(sock_now);
                    }
                    else if (message[0] == 'w')
                    {
                        int index;
                        sscanf(message, "w %d", &index);
                        printf("client: write request [%d]\n", index);
                        client_write(sock_now, index);
                    }
                    else if (message[0] == 'p')
                    {
                        int cpid;
                        sscanf(message, "p %d", &cpid);
                        printf("client: pid = %d\n", cpid);
                        int pid = getpid();
                        if (send(sock_now, &pid, sizeof(pid), 0) == -1)
                        {
                            perror("send");
                            exit(EXIT_FAILURE);
                        }
                    }
                    else
                    {
                        printf("client: undefined request\n");
                        if (send(sock_now, "error: undefinded request", BUFSIZE, 0) == -1)
                        {
                            perror("send");
                            exit(EXIT_FAILURE);
                        }
                    }
                }
                clock_t end = clock();
                printf("time: %d\n", end - start);
            }
        }
    }
}