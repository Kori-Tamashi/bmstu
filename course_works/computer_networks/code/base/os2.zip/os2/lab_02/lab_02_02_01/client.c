#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <signal.h>

#define SERVER_IP "127.0.0.1"
#define SERVER_PORT 8082

int sock_fd = 0;

void handler()
{
    close(sock_fd);
    exit(0);
}

int main(int argc, char **argv)
{
    signal(SIGINT, handler);

    struct sockaddr_in serv_addr;
    char buffer[26] = {};

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(SERVER_PORT);
    serv_addr.sin_addr.s_addr = inet_addr(SERVER_IP);

    while (1)
    {
        if ((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
        {
            perror("Socket creation error");
            return -1;
        }

        if (connect(sock_fd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
        {
            perror("Connection failed");
            close(sock_fd);
            return -1;
        }

        char read_char[10];
        read_char[0] = 'r';

        if (send(sock_fd, &read_char, sizeof(int), 0) < 0)
        {
            perror("Send failed");
            close(sock_fd);
            return -1;
        }

        int bytes_received = read(sock_fd, &buffer, 26);
        if (bytes_received < 0)
        {
            perror("Read failed");
            close(sock_fd);
            return -1;
        }

        for (int i = 0; i < 26; ++i)
        {
            if (buffer[i] != ' ')
                printf("%c ", buffer[i]);
            else
                printf("_ ");
        }
        printf("\n");

        int flag = 1;
        int pos = 0;

        for (pos = 0; pos < 26 && flag; ++pos)
        {
            if (buffer[pos] != ' ')
            {
                flag = 0;
                break;
            }
        }

        if (!flag)
        {
            printf("pos = %d\n", pos);
            if (send(sock_fd, &pos, sizeof(int), 0) < 0)
            {
                perror("Send failed");
                close(sock_fd);
                return -1;
            }
        }
        else
        {
            close(sock_fd);
            exit(0);
        }

        char ans[10] = {};
        read(sock_fd, &ans, sizeof(int));

        printf("ans = %c\n", ans[0]);

        if (ans[0] == 'n')
            printf("Не удалось занять место\n");
        else
        {
            printf("Занято место %c\n", pos);
        }
        close(sock_fd);

        sleep(2);
    }

    close(sock_fd);

    return 0;
}