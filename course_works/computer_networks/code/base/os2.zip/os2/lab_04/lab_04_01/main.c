#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include <stdint.h>
#include <fcntl.h>
#include <stdlib.h>

#include "descr.h"

#define BUFF_SIZE 1024
#define PATH_SIZE 100

void print_file(char *pid, FILE *file, char *filename)
{
    char path[PATH_SIZE];
    snprintf(path, PATH_SIZE, "/proc/%s/%s", pid, filename);
    FILE *f = fopen(path, "r");
    if (f == NULL)
    {
        perror("error fopen");
        exit(EXIT_FAILURE);
    }

    int len;
    char buf[BUFF_SIZE];

    while ((len = fread(buf, sizeof(char), BUFF_SIZE, f)) > 0)
    {
        for (int i = 0; i < len; i++)
            if (buf[i] == 0)
                buf[i] = '\n';
        buf[len] = 0;
        fprintf(file, "%s", buf);
    }
    fclose(f);
}

void print_environ(char *pid, FILE *file)
{
    fprintf(file, "\nenviron:\n");
    print_file(pid, file, "environ");
}

void print_stat(char *pid, FILE *file)
{
    fprintf(file, "\nstat:\n");

    char path[PATH_SIZE];
    snprintf(path, PATH_SIZE, "/proc/%s/stat", pid);

    char buf[BUFF_SIZE + 1];
    FILE *f = fopen(path, "r");
    fread(buf, 1, BUFF_SIZE, f);

    char *stat = strtok(buf, " ");

    int i = 0;

    while (stat != NULL)
    {
        fprintf(file, stat_no_descr[i++], stat);
        stat = strtok(NULL, " ");
    }

//    fprintf(file, "state: %s\n", stat);

    fclose(f);
}

void print_cmdline(char *pid, FILE *file)
{
    fprintf(file, "\ncmdline:\n");
    print_file(pid, file, "cmdline");
}

void print_fd(char *pid, FILE *file)
{
    fprintf(file, "\nfd:\n");
    char dir_path[PATH_SIZE];
    char link_path[PATH_SIZE];
    char buf[BUFF_SIZE];

    snprintf(dir_path, PATH_SIZE, "/proc/%s/fd", pid);
    DIR *dp = opendir(dir_path);
    if (!dp)
    {
        perror("opendir failed");
        return;
    }

    struct dirent *dirp;
    while ((dirp = readdir(dp)) != NULL)
    {
        if (strcmp(dirp->d_name, ".") != 0 && strcmp(dirp->d_name, "..") != 0)
        {
            snprintf(link_path, PATH_SIZE, "%s/%s", dir_path, dirp->d_name);

            ssize_t len = readlink(link_path, buf, BUFF_SIZE - 1);
            if (len == -1)
            {
                perror("readlink failed");
                continue;
            }
            buf[len] = '\0';

            fprintf(file, "%s -> %s\n", dirp->d_name, buf);
        }
    }

    closedir(dp);
}

void print_link(char *pid, FILE *file, char *name)
{
    char path[PATH_SIZE];
    snprintf(path, PATH_SIZE, "/proc/%s/%s", pid, name);

    char buf[BUFF_SIZE];
    int len = readlink(path, buf, BUFF_SIZE);

    if (len < 1)
    {
        perror("error: readlink");
        exit(EXIT_FAILURE);
    }

    buf[len] = '\0';

    fprintf(file, "%s\n", buf);
}

void print_cwd(char *pid, FILE *file)
{
    fprintf(file, "\ncwd:\n");
    print_link(pid, file, "cwd");
}

void print_exe(char *pid, FILE *file)
{
    fprintf(file, "\nexe:\n");
    print_link(pid, file, "exe");
}

void print_root(char *pid, FILE *file)
{
    fprintf(file, "\nroot:\n");
    print_link(pid, file, "root");
}

#include <stdio.h>
#include <string.h>

void print_anonymous_maps(const char *pid)
{
    char path[256];
    snprintf(path, sizeof(path), "/proc/%s/maps", pid);

    FILE *f = fopen(path, "r");
    if (!f)
    {
        perror("fopen");
        return;
    }

    printf("Anonymous mappings for PID %s:\n", pid);
    printf("%-18s %-18s %-5s %-10s %s\n",
           "Start", "End", "Perm", "Offset", "Flags");

    char line[1024];
    while (fgets(line, sizeof(line), f))
    {
        // Проверяем, что строка заканчивается на " 0" (нет inode) или содержит "[anon]"/"[stack]"/etc.
        if (strstr(line, " 0 ") || strstr(line, "[anon]") ||
            strstr(line, "[heap]") || strstr(line, "[stack]"))
        {
            // Вырезаем путь (если есть) для чистого вывода
            char *p = strchr(line, '/');
            if (!p || strncmp(p, "/dev/zero", 9) == 0)
            { // Игнорируем /dev/zero
                printf("%.17s\n", line); // Обрезаем \n из оригинала
            }
        }
    }
    fclose(f);
}

#define PAGE_SIZE sysconf(_SC_PAGESIZE)

void print_maps(char *pid, FILE *out)
{
    char path[256];
    snprintf(path, sizeof(path), "/proc/%s/maps", pid);

    FILE *f = fopen(path, "r");
    if (!f)
    {
        perror("fopen");
        return;
    }

    fprintf(out, "\nMemory regions with page boundaries (PID %s, page size: %ld):\n", pid, PAGE_SIZE);
    fprintf(out, "%-16s %-16s %-5s %-10s %-9s %-8s %s\n",
            "Start", "End", "Perm", "Offset", "Device", "Inode", "Path");

    char line[1024];
    while (fgets(line, sizeof(line), f))
    {
        unsigned long start, end, offset, inode;
        char perms[5], dev[12], pathname[256] = "";
        int major, minor;

        if (sscanf(line, "%lx-%lx %4s %lx %d:%d %lu %255[^\n]",
                   &start, &end, perms, &offset, &major, &minor, &inode, pathname) >= 7)
        {
            unsigned long page_start = start & ~(PAGE_SIZE - 1);
            unsigned long page_end = (end + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1);
            int page_count = (page_end - page_start) / PAGE_SIZE;
            // Вывод основной информации о регионе
            fprintf(out, "%d %016lx-%016lx %-5s %010lx %03d:%03d %-8lu %s\n", page_count,
                    start, end, perms, offset, major, minor, inode, pathname);
        }
    }
    fclose(f);
}

//void print_maps(char *pid, FILE *file)
//{
//    fprintf(file, "\nmaps:\n");
//    char path[PATH_SIZE];
//    snprintf(path, PATH_SIZE, "/proc/%s/maps", pid);
//    FILE *f = fopen(path, "r");
//    char buf[BUFF_SIZE];
//
//    int len;
//    while ((len = fread(buf, sizeof(char), BUFF_SIZE, f)) > 0)
//    {
//        fwrite(buf, sizeof(char), len, file);
//    }
//
//    fclose(f);
//}

void print_io(char *pid, FILE *file)
{
    fprintf(file, "\nio:\n");
    print_file(pid, file, "io");
}

void print_comm(char *pid, FILE *file)
{
    fprintf(file, "\ncomm:\n");
    char path[PATH_SIZE];
    snprintf(path, PATH_SIZE, "/proc/%s/comm", pid);

    char buf[BUFF_SIZE];
    FILE *f = fopen(path, "r");

    if (f == NULL)
    {
        perror("error: fopen");
        exit(EXIT_FAILURE);
    }

    int len = fread(buf, sizeof(char), BUFF_SIZE, f);
    buf[len] = '\0';

    fprintf(file, "%s", buf);
    fclose(f);
}

void print_task(char *pid, FILE *file)
{
    fprintf(file, "task:\n");
    char path[PATH_SIZE];
    snprintf(path, PATH_SIZE, "/proc/%s/task", pid);
    struct dirent *dirp;
    DIR *dp = opendir(path);
    char buf[BUFF_SIZE];
    while ((dirp = readdir(dp)) != NULL)
    {
        if ((strcmp(dirp->d_name, ".") != 0) &&
            (strcmp(dirp->d_name, "..") != 0))
        {
            fprintf(file, "%s\n", dirp->d_name);
        }
    }
    closedir(dp);
}

void print_page(uint64_t address, uint64_t data, FILE *file)
{
    fprintf(file, "0x%-16lx : %-16lx %-10ld %-10ld %-10ld %-10ld\n", address,
            data & (((uint64_t) 1 << 55) - 1), (data >> 55) & 1,
            (data >> 61) & 1, (data >> 62) & 1, (data >> 63) & 1);
}

void print_pagemap(char *pid, FILE *file)
{
    fprintf(file, "       addr        : pfn          soft-dirty file/shared swapped    present\n");
    char path[PATH_SIZE];
    snprintf(path, PATH_SIZE, "/proc/%s/maps", pid);
    FILE *maps = fopen(path, "r");

    snprintf(path, PATH_SIZE, "/proc/%s/pagemap", pid);
    int pm_fd = open(path, O_RDONLY);


    char buf[BUFF_SIZE + 1] = "\0";
    int len;

    // чтение maps
    while ((len = fread(buf, 1, BUFF_SIZE, maps)) > 0)
    {
        for (int i = 0; i < len; ++i)
            if (buf[i] == 0)
                buf[i] = '\n';
        buf[len] = '\0';

        char *save_row;
        char *row = strtok_r(buf, "\n", &save_row);

        while (row)
        {
            // получение столбца участка адресного пространства
            char *addresses = strtok(row, " ");
            char *start_str, *end_str;

            // получение начала и конца участка адресного пространства
            if ((start_str = strtok(addresses, "-")) && (end_str = strtok(NULL, "-")))
            {
                uint64_t start = strtoul(start_str, NULL, 16);
                uint64_t end = strtoul(end_str, NULL, 16);

                for (uint64_t i = start; i < end; i += sysconf(_SC_PAGE_SIZE))
                {
                    uint64_t offset;
                    // поиск смещения, по которому в pagemap находится информация о текущей странице
                    uint64_t index = i / sysconf(_SC_PAGE_SIZE) * sizeof(offset);

                    pread(pm_fd, &offset, sizeof(offset), index);
                    print_page(i, offset, file);
                }
            }

            row = strtok_r(NULL, "\n", &save_row);
        }
    }

    fclose(maps);
    close(pm_fd);
}

typedef struct
{
    unsigned long start_addr;
    unsigned long end_addr;
} MemoryRegion;

void print_region(int mem_fd, unsigned long start_addr,
                  unsigned long end_addr, FILE *stream)
{
    size_t region_size = end_addr - start_addr;
    void *buffer = malloc(region_size);
    if (!buffer)
    {
        perror("malloc");
        return;
    }
    if (lseek(mem_fd, start_addr, SEEK_SET) == (off_t) -1)
    {
        perror("lseek");
        free(buffer);
        return;
    }
    ssize_t bytes_read = read(mem_fd, buffer, region_size);
    if (bytes_read == -1)
    {
        perror("read");
        free(buffer);
        return;
    }
    fprintf(stream, "Memory region: %lx-%lx\n", start_addr, end_addr);
    for (size_t i = 0; i < region_size; i++)
    {
        fprintf(stream, "%02x", ((unsigned char *) buffer)[i]);
        if ((i + 1) % 16 == 0) fprintf(stream, "\n");
    }
    fprintf(stream, "\n");
    free(buffer);
}

MemoryRegion *get_memory_regions(int pid, size_t *region_count)
{
    char path[PATH_MAX];
    snprintf(path, PATH_MAX, "/proc/%d/maps", pid);
    FILE *file = fopen(path, "r");
    if (!file)
    {
        perror("fopen");
        return NULL;
    }
    size_t capacity = 10;
    MemoryRegion *regions = malloc(capacity * sizeof(MemoryRegion));
    if (!regions)
    {
        perror("malloc");
        fclose(file);
        return NULL;
    }
    char *line = NULL;
    size_t line_size = 0;
    size_t count = 0;
    while (getline(&line, &line_size, file) != -1)
    {
        unsigned long start_addr, end_addr;
        if (sscanf(line, "%lx-%lx", &start_addr, &end_addr) == 2)
        {
            if (count >= capacity)
            {
                capacity *= 2;
                MemoryRegion *new_regions = realloc(regions, capacity * sizeof(MemoryRegion));
                if (!new_regions)
                {
                    perror("realloc");
                    free(regions);
                    fclose(file);
                    free(line);
                    return NULL;
                }
                regions = new_regions;
            }
            regions[count].start_addr = start_addr;
            regions[count].end_addr = end_addr;
            count++;
        }
    }
    fclose(file);
    free(line);
    *region_count = count;
    return regions;
}

void print_mem(int pid, FILE *stream)
{
    size_t region_count = 0;
    MemoryRegion *regions = get_memory_regions(pid, &region_count);
    if (!regions)
    {
        fprintf(stderr, "Failed to get memory regions\n");
        return;
    }
    char mem_path[PATH_MAX];
    snprintf(mem_path, PATH_MAX, "/proc/%d/mem", pid);
    int mem_fd = open(mem_path, O_RDONLY);
    if (mem_fd == -1)
    {
        perror("open");
        free(regions);
        return;
    }
    for (size_t i = 0; i < region_count; i++)
    {
        fprintf(stream, "Region %zu: %lx-%lx\n",
                i, regions[i].start_addr, regions[i].end_addr);
        print_region(mem_fd, regions[i].start_addr,
                     regions[i].end_addr, stream);
    }
    close(mem_fd);
    free(regions);
}

int main(int argc, char **argv)
{
    char *pid = "self";
    FILE *file = stdout;

    switch (argc)
    {
        case 1:
            break;
        case 2:
            pid = argv[1];
            break;
        case 3:
            pid = argv[1];
            file = fopen(argv[2], "w");
            break;
        default:
            exit(EXIT_FAILURE);
    }


    print_environ(pid, file);
    print_stat(pid, file);
    print_cmdline(pid, file);
    print_fd(pid, file);
    print_cwd(pid, file);
    print_exe(pid, file);
    print_root(pid, file);
    print_io(pid, file);
    print_comm(pid, file);
    print_task(pid, file);
    print_mem(getpid(), file);
    print_maps(pid, file);
    print_pagemap(pid, file);


    fclose(file);
}