#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include <stdint.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <inttypes.h>
#include <sys/types.h>
#include <sys/stat.h>

typedef int bool;

#define PATH_MAX 4096
#define PAGE_SIZE sysconf(_SC_PAGESIZE)
#define PFN_MASK ((1ULL << 55) - 1)

#define BUFF_SIZE 1024
#define PATH_SIZE 256
#define PAGE_SIZE 4096 


void print_file(const char *pid, FILE *out, const char *filename) {
    char path[PATH_SIZE];
    snprintf(path, PATH_SIZE, "/proc/%s/%s", pid, filename);
    FILE *f = fopen(path, "r");
    if (!f) {
        perror("fopen");
        return;
    }

    char buf[BUFF_SIZE];
    size_t len;
    while ((len = fread(buf, 1, BUFF_SIZE, f)) > 0) {
        for (size_t i = 0; i < len; i++)
            if (buf[i] == '\0') buf[i] = '\n';
        fwrite(buf, 1, len, out);
    }
    fclose(f);
}

void print_environ(const char *pid, FILE *out) {
    fprintf(out, "\n=== Доступные переменные окружения (environ) ===\n");
    print_file(pid, out, "environ");
}

void print_stat(const char *pid, FILE *out) {
    fprintf(out, "\n=== Параметры процесса (stat) ===\n");
    char path[PATH_SIZE];
    snprintf(path, PATH_SIZE, "/proc/%s/stat", pid);
    
    FILE *f = fopen(path, "r");
    if (!f) {
        perror("fopen");
        return;
    }

    char buf[BUFF_SIZE];
    if (!fgets(buf, BUFF_SIZE, f)) {
        fclose(f);
        return;
    }
    fclose(f);

    // Official field names from kernel documentation
    const char *stat_fields[] = {
        "pid", "comm", "state", "ppid", "pgrp", "session", "tty_nr",
        "tpgid", "flags", "minflt", "cminflt", "majflt", "cmajflt",
        "utime", "stime", "cutime", "cstime", "priority", "nice",
        "num_threads", "itrealvalue", "starttime", "vsize", "rss",
        "rsslim", "startcode", "endcode", "startstack", "kstkesp",
        "kstkeip", "signal", "blocked", "sigignore", "sigcatch", "wchan",
        "nswap", "cnswap", "exit_signal", "processor", "rt_priority",
        "policy", "delayacct_blkio_ticks", "guest_time", "cguest_time",
        "start_data", "end_data", "start_brk", "arg_start", "arg_end",
        "env_start", "env_end", "exit_code"
    };

    char *p = buf;
    int field_num = 0;
    char *token;
    char comm[256];

    // Process remaining fields
    while ((token = strtok_r(p, " ", &p))) {
        if (field_num >= 0 && field_num < sizeof(stat_fields)/sizeof(stat_fields[0])) {
            fprintf(out, "%-23s %s\n", stat_fields[field_num], token);
        }
        field_num++;
    }
}

void print_cmdline(const char *pid, FILE *out) {
    fprintf(out, "\n=== Строка запуска процесса (cmdline) ===\n");
    print_file(pid, out, "cmdline");
}

void print_fd(const char *pid, FILE *out) {
    fprintf(out, "\n=== Открытые файловые дескрипторы (fd) ===\n");
    char dir_path[PATH_SIZE];
    snprintf(dir_path, PATH_SIZE, "/proc/%s/fd", pid);
    DIR *dir = opendir(dir_path);
    if (!dir) {
        perror("opendir");
        return;
    }

    struct dirent *entry;
    char link_path[PATH_SIZE], target[BUFF_SIZE];
    while ((entry = readdir(dir))) {
        if (entry->d_type == DT_LNK) {
            snprintf(link_path, PATH_SIZE, "%s/%s", dir_path, entry->d_name);
            ssize_t len = readlink(link_path, target, BUFF_SIZE);
            if (len != -1) {
                target[len] = '\0';
                fprintf(out, "%s -> %s\n", entry->d_name, target);
            }
        }
    }
    closedir(dir);
}

void print_symlink(const char *pid, FILE *out, const char *name, const char *title) {
    char path[PATH_SIZE];
    snprintf(path, PATH_SIZE, "/proc/%s/%s", pid, name);
    char buf[BUFF_SIZE];
    ssize_t len = readlink(path, buf, BUFF_SIZE);
    if (len == -1) {
        perror("readlink");
        return;
    }
    buf[len] = '\0';

    if (title)
        fprintf(out, "\n=== %s (%s) ===\n%s\n", title, name, buf);
    else
        fprintf(out, "\n=== %s ===\n%s\n", name, buf);
}


void print_maps(const char *pid, FILE *out) {
    fprintf(out, "\n=== Отображения памяти (maps) ===\n");
    fprintf(out, "%-12s %-12s %-10s %-4s %-9s %-5s %-6s %-2s %s\n",
       "Start", "End", "Page Count", "Perm", "Offset", "Dev", "Inode", " ", "Pathname/Flags");
    
    char path[PATH_SIZE];
    snprintf(path, PATH_SIZE, "/proc/%s/maps", pid);
    FILE *f = fopen(path, "r");
    if (!f) {
        perror("fopen");
        return;
    }

    unsigned long long total_size = 0;
    unsigned long long min_addr = ULLONG_MAX;
    unsigned long long max_addr = 0;
    char line[BUFF_SIZE];

    while (fgets(line, sizeof(line), f)) {

        char line_copy[BUFF_SIZE];
        strcpy(line_copy, line);

        // Парсим адреса начала и конца
        char *start_str = line_copy;
        char *dash = strchr(line_copy, '-');
        if (!dash) {
            fputs(line, out);
            continue;
        }
        *dash = '\0';
        char *end_str = dash + 1;
        char *space = strchr(end_str, ' ');
        if (!space) {
            fputs(line, out);
            continue;
        }
        *space = '\0';

        unsigned long long start = strtoull(start_str, NULL, 16);
        unsigned long long end = strtoull(end_str, NULL, 16);

        // Считаем количество страниц
        unsigned long long page_count = (end - start) / PAGE_SIZE;

        if (start < min_addr) min_addr = start;
        if (end > max_addr) max_addr = end;
        total_size += (end - start);
        char *rest = space + 1;

        char perms[5] = "";
        char offset[17] = "";
        char dev[6] = "";
        char inode[11] = "";
        char pathname[PATH_SIZE] = "";

        sscanf(rest, "%4s %16s %5s %10s %[^\n]", perms, offset, dev, inode, pathname);

        // Выводим в нужном формате
        fprintf(out, "%-12s-%-12s %-10llu %-4s %-9s %-5s %-6s  %-2s %s\n",
                start_str, end_str, page_count, perms, offset, dev, inode, " ",  pathname);
    }
    fclose(f);

    // Форматируем вывод суммарного размера и диапазона
    const char *units[] = {"Б", "КБ", "МБ", "ГБ", "ТБ"};

    double size = total_size;
    int unit_idx = 0;
    while (size >= 1024 && unit_idx < 4) {
        size /= 1024;
        unit_idx++;
    }
    fprintf(out, "\nСуммарный размер регионов: %.2f %s (%llu байт)\n", 
            size, units[unit_idx], total_size);

    if (max_addr > min_addr) {
        unsigned long long range = max_addr - min_addr;
        double range_size = range;
        unit_idx = 0;
        while (range_size >= 1024 && unit_idx < 4) {
            range_size /= 1024;
            unit_idx++;
        }
        fprintf(out, "Общий диапазон адресов: %.2f %s (%llu байт)\n\n",
                range_size, units[unit_idx], range);
    } else {
        fprintf(out, "Не удалось определить диапазон адресов\n\n");
    }
}

void print_anonymous_maps(const char *pid, FILE *out) {
    
    fprintf(out, "\n=== Анонимные отображения памяти (anonymous maps) ===\n");
    char path[256];
    snprintf(path, sizeof(path), "/proc/%s/maps", pid);

    FILE *f = fopen(path, "r");
    if (!f) {
        perror("Failed to open maps file");
        return;
    }

    fprintf(out, "%-16s %-16s %-6s %-10s %-8s %s\n", 
           "Start", "End", "Perm", "Offset", "Inode", "Pathname/Flags");

    char line[1024];
    while (fgets(line, sizeof(line), f)) {
        unsigned long start, end;
        char perms[5], offset[16], dev[12], inode[16], pathname[256];

        int parsed = sscanf(line, "%lx-%lx %4s %15s %11s %15s %255[^\n]",
                            &start, &end, perms, offset, dev, inode, pathname);

        bool is_anonymous = (strcmp(inode, "0") == 0) ||
                           (strstr(pathname, "[heap]") != NULL) ||
                           (strstr(pathname, "[stack]") != NULL) ||
                           (strstr(pathname, "[anon]") != NULL);

        bool is_special = (strstr(pathname, "/dev/zero") != NULL) || 
                         (strstr(pathname, "[vsyscall]") != NULL);

        if (is_anonymous && !is_special) {
            fprintf(out, "%016lx-%016lx %-6s %-10s %-8s %s\n",
                   start, end, perms, offset, inode, 
                   pathname[0] ? pathname : "[anonymous]");
        }
    }
    fclose(f);
}

void print_pagemap(const char *pid, FILE *out) {
    fprintf(out, "\n=== Карта отображения памяти (pagemap) ===\n");
    char maps_path[256], pagemap_path[256];
    snprintf(maps_path, sizeof(maps_path), "/proc/%s/maps", pid);
    snprintf(pagemap_path, sizeof(pagemap_path), "/proc/%s/pagemap", pid);

    FILE *maps_file = fopen(maps_path, "r");
    int pm_fd = open(pagemap_path, O_RDONLY);

    if (!maps_file || pm_fd == -1) {
        perror("Error opening files");
        if (maps_file) fclose(maps_file);
        if (pm_fd != -1) close(pm_fd);
        return;
    }

    fprintf(out, "%-16s %-10s %-8s %-6s %-7s %-6s %-7s\n",
           "Virtual Page", "PFN", "Present", "Swapped", "File", "Exclusive", "SoftDirty");

    char line[1024];
    while (fgets(line, sizeof(line), maps_file)) {
        uint64_t start, end;
        if (sscanf(line, "%" PRIx64 "-%" PRIx64, &start, &end) != 2)
            continue;

        for (uint64_t addr = start; addr < end; addr += PAGE_SIZE) {
            uint64_t index = (addr / PAGE_SIZE) * sizeof(uint64_t);
            uint64_t pm_entry;
            
            if (pread(pm_fd, &pm_entry, sizeof(pm_entry), index) != sizeof(uint64_t))
                continue;

            uint64_t pfn = pm_entry & PFN_MASK;
            int present = !!(pm_entry & (1ULL << 63));
            int swapped = !!(pm_entry & (1ULL << 62));
            int file_or_shared = !!(pm_entry & (1ULL << 61));
            int exclusive = !!(pm_entry & (1ULL << 56));
            int soft_dirty = !!(pm_entry & (1ULL << 55));

            fprintf(out, "0x%-14" PRIx64 " %-10" PRIu64 " %-8s %-7s %-7s %-9s %-9s\n",
                   addr,
                   pfn,
                   present ? "Yes" : "No",
                   swapped ? "Yes" : "No",
                   file_or_shared ? "File" : "Anon",
                   exclusive ? "Yes" : "No",
                   soft_dirty ? "Yes" : "No");
        }
    }

    fclose(maps_file);
    close(pm_fd);
}

void print_io(const char *pid, FILE *out) {
    fprintf(out, "\n=== Статистика ввода-вывода (io) ===\n");
    print_file(pid, out, "io");
}

void print_comm(const char *pid, FILE *out) {
    fprintf(out, "\n=== Имя процесса (comm) ===\n");
    print_file(pid, out, "comm");
}

void print_tasks(const char *pid, FILE *out) {
    fprintf(out, "\n=== Задачи (tasks) ===\n");
    char path[PATH_SIZE];
    snprintf(path, PATH_SIZE, "/proc/%s/task", pid);
    DIR *dir = opendir(path);
    if (!dir) {
        perror("opendir");
        return;
    }

    struct dirent *entry;
    while ((entry = readdir(dir))) {
        if (entry->d_type == DT_DIR && strcmp(entry->d_name, ".") && strcmp(entry->d_name, ".."))
            fprintf(out, "%s\n", entry->d_name);
    }
    closedir(dir);
}

typedef struct {
    unsigned long start_addr;
    unsigned long end_addr;
} MemoryRegion;

void print_region(int mem_fd, unsigned long start_addr, 
                 unsigned long end_addr, FILE *stream) {
    size_t region_size = end_addr - start_addr;
    unsigned char *buffer = malloc(region_size);
    
    if (!buffer) {
        perror("malloc");
        return;
    }

    off_t offset = lseek(mem_fd, start_addr, SEEK_SET);
    if (offset == (off_t)-1) {
        perror("lseek");
        free(buffer);
        return;
    }

    ssize_t bytes_read = read(mem_fd, buffer, region_size);
    if (bytes_read == -1) {
        perror("read");
        free(buffer);
        return;
    }

    fprintf(stream, "\nMemory region: 0x%lx-0x%lx\n", start_addr, end_addr);
    for (size_t i = 0; i < region_size; i++) {
        fprintf(stream, "%02x ", buffer[i]);
        if ((i + 1) % 16 == 0) fprintf(stream, "\n");
    }
    fprintf(stream, "\n");
    free(buffer);
}

MemoryRegion* get_memory_regions(int pid, size_t *region_count) {
    char path[PATH_MAX];
    snprintf(path, PATH_MAX, "/proc/%d/maps", pid);
    
    FILE *file = fopen(path, "r");
    if (!file) {
        perror("fopen");
        return NULL;
    }

    size_t capacity = 10;
    MemoryRegion *regions = malloc(capacity * sizeof(MemoryRegion));
    if (!regions) {
        perror("malloc");
        fclose(file);
        return NULL;
    }

    char *line = NULL;
    size_t line_size = 0;
    size_t count = 0;

    while (getline(&line, &line_size, file) != -1) {
        unsigned long start, end;
        if (sscanf(line, "%lx-%lx", &start, &end) == 2) {
            if (count >= capacity) {
                capacity *= 2;
                MemoryRegion *new_regions = realloc(regions, capacity * sizeof(MemoryRegion));
                if (!new_regions) {
                    perror("realloc");
                    free(regions);
                    fclose(file);
                    free(line);
                    return NULL;
                }
                regions = new_regions;
            }
            regions[count].start_addr = start;
            regions[count].end_addr = end;
            count++;
        }
    }

    fclose(file);
    free(line);
    *region_count = count;
    return regions;
}

void print_mem(int pid, FILE *stream) {
    size_t region_count = 0;
    MemoryRegion *regions = get_memory_regions(pid, &region_count);
    
    if (!regions) {
        fprintf(stderr, "Failed to get memory regions\n");
        return;
    }

    char mem_path[PATH_MAX];
    snprintf(mem_path, PATH_MAX, "/proc/%d/mem", pid); 
    
    int mem_fd = open(mem_path, O_RDONLY);
    if (mem_fd == -1) {
        perror("open");
        free(regions);
        return;
    }

    for (size_t i = 0; i < region_count; i++) {
        fprintf(stream, "\n=== Region %zu ===\n", i + 1);
        print_region(mem_fd, regions[i].start_addr, regions[i].end_addr, stream);
    }

    close(mem_fd);
    free(regions);
}

int main(int argc, char **argv) {
    if (argc < 2 || argc > 3) {
        fprintf(stderr, "Usage: %s <PID> [output_file]\n", argv[0]);
        return 1;
    }

    char* pid = argv[1];
    FILE *out = stdout;
    if (argc == 3) {
        out = fopen(argv[2], "w");
        if (!out) {
            fprintf(stderr, "Failed to open %s: %s\n", 
                    argv[2], strerror(errno));
            return 1;
        }
    }

    print_environ(pid, out);
    print_stat(pid, out);
    print_cmdline(pid, out);
    print_fd(pid, out);
    print_symlink(pid, out, "cwd", "Текущая рабочая директория");
    print_symlink(pid, out, "exe", "Путь к исполняемому файлу");
    print_symlink(pid, out, "root", "Корень файловой системы");
    print_io(pid, out);
    print_comm(pid, out);
    print_tasks(pid, out);
    print_maps(pid, out);
    print_anonymous_maps(pid, out);
    print_pagemap(pid, out);
    print_mem(getpid(), out);

    if (out != stdout) {
        fclose(out);
    }
    
    return 0;
}