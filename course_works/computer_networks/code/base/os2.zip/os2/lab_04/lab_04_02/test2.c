#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <stdbool.h>

void *thread_routine(void *arg)
{
    sleep(15);
    pthread_exit(EXIT_SUCCESS);
}

int main() {
    
    int a = 1;
    int b = 2;
    int c = a + b;

    pthread_t tid;

    for (int i = 0; i < 5; i++)
    {
        if (pthread_create(&tid, NULL, thread_routine, NULL) != 0)
        {
            perror("Thread create failed");
            exit(EXIT_FAILURE);
        }

        if (pthread_detach(tid) != 0)
        {
            perror("Thread detach failed");
            exit(EXIT_FAILURE);
        }
    }
    sleep(120);
    return 0;
}