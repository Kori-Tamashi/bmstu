#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <stdbool.h>

int main() {
    
    int a = 1;
    int b = 2;
    int c = a + b;

    int *ptr = (int*) malloc(sizeof(int) * 4096 * 8);
    if (ptr == NULL)
    {
        perror("malloc");
        exit(1);
    }
    sleep(120);
    free(ptr);
    return 0;
}