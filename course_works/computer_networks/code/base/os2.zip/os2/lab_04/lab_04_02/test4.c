/* Пример кода на C, создающий анонимные отображения вида:
   76a598000000-76a598021000 rw-p 
   76a598021000-76a59c000000 ---p 
   (типично для многопоточных программ с glibc)
*/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define N_THREADS 32  // Больше чем ядер CPU × 2
#define ALLOC_SIZE 128 // 128KB для превышения mmap_threshold

void* thread_func(void* arg) {
    // Аллокация памяти, форсирующая использование отдельной арены
    void* ptr = malloc(ALLOC_SIZE * 1024);
    
    // Удерживаем память до завершения
    pause(); // Ожидание сигнала
    return NULL;
}

int main() {
    pthread_t threads[N_THREADS];
    
    for(int i = 0; i < N_THREADS; i++) {
        pthread_create(&threads[i], NULL, thread_func, NULL);
    }
    
    // Пауза для анализа maps
    printf("PID: %d\n", getpid());
    getchar();
    
    return 0;
}