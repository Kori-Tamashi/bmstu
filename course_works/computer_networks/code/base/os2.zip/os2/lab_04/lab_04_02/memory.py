def calculate_memory_usage(filename):
    total_size = 0
    min_address = None
    max_address = 0

    with open(filename, 'r') as file:
        for line in file:
            line = line.strip()
            if not line or line.startswith('===') or line.startswith('Start'):
                continue
            
            parts = line.split()
            address_range = parts[0]
            
            try:
                start, end = address_range.split('-')
                start_addr = int(start, 16)
                end_addr = int(end, 16)
                
                # Обновляем min и max адреса
                if min_address is None or start_addr < min_address:
                    min_address = start_addr
                if end_addr > max_address:
                    max_address = end_addr
                
                # Считаем размер региона
                size = end_addr - start_addr
                if size > 0:
                    total_size += size

            except (ValueError, IndexError):
                continue

    # Общий размер через сумму регионов
    sum_size = total_size
    # Общий диапазон адресного пространства
    range_size = max_address - min_address if min_address is not None else 0

    # Форматирование вывода
    def format_size(size):
        units = ['Б', 'КБ', 'МБ', 'ГБ', 'ТБ']
        unit_index = 0
        while size >= 1024 and unit_index < len(units) - 1:
            size /= 1024
            unit_index += 1
        return f"{size:.2f} {units[unit_index]} ({int(size * (1024 ** unit_index))} байт)"

    return (
        f"Суммарный размер регионов: {format_size(sum_size)}\n"
        f"Общий диапазон адресов: {format_size(range_size)}"
    )

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        print("Использование: python script.py <имя_файла>")
        sys.exit(1)
    
    result = calculate_memory_usage(sys.argv[1])
    print(result)