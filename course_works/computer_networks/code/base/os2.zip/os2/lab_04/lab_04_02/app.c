#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <stdbool.h>

#define NUM_THREADS 5

pthread_mutex_t lock;
bool stop_flag = false;

// Функция, которую выполняют потоки
void* thread_func(void* arg) {
    int thread_num = *(int*)arg;
    printf("Поток %d запущен\n", thread_num);
    
    while (1) {
        pthread_mutex_lock(&lock);
        if (stop_flag) {
            pthread_mutex_unlock(&lock);
            break;
        }
        pthread_mutex_unlock(&lock);
        
        sleep(1);
    }
    
    printf("Поток %d завершен\n", thread_num);
    return NULL;
}

int main() {
    pthread_t threads[NUM_THREADS];
    int thread_nums[NUM_THREADS];
    
    pthread_mutex_init(&lock, NULL);

    for (int i = 0; i < NUM_THREADS; i++) {
        thread_nums[i] = i;
        if (pthread_create(&threads[i], NULL, thread_func, &thread_nums[i]) != 0) {
            perror("Ошибка создания потока");
            return 1;
        }
    }

    sleep(120);

    pthread_mutex_lock(&lock);
    stop_flag = true;
    pthread_mutex_unlock(&lock);

    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }

    pthread_mutex_destroy(&lock);

    printf("Все потоки завершены\n");
    return 0;
}