#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <stdbool.h>

int main() {
    
    int a = 1;
    int b = 2;
    int c = a + b;
    sleep(120);
    return 0;
}