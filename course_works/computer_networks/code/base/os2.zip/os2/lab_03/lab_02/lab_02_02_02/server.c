#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <signal.h>
#include <sys/sem.h>
#include <sys/stat.h>
#include <errno.h>
#include <sys/shm.h>
#include <fcntl.h>
#include <pthread.h>
#include <arpa/inet.h>
#include "consts.h"

#define ACTIVE_READER 0
#define ACTIVE_WRITER 1
#define WRITE_QUEUE   2
#define READ_QUEUE    3
#define BIN_SEM       4

struct sembuf start_read[] = {
    {READ_QUEUE,    1, 0},
    {WRITE_QUEUE,   0, 0},
    {ACTIVE_WRITER, 0, 0},
    {ACTIVE_READER, 1, 0},
    {READ_QUEUE,   -1, 0}
};

struct sembuf stop_read[] = {
    {ACTIVE_READER, -1, 0}
};

struct sembuf start_write[] = {
    {WRITE_QUEUE,   1, 0},
    {ACTIVE_READER, 0, 0},
    {BIN_SEM,      -1, 0},
    {ACTIVE_WRITER, 1, 0},
    {WRITE_QUEUE,  -1, 0}
};

struct sembuf stop_write[] = {
    {ACTIVE_WRITER, -1, 0},
    {BIN_SEM,        1, 0}
};

int perms = 0;
int shm_fd = 0;
int sem_id = 0;
char *buffer = NULL;

pthread_t tid = 0;
int server_sock_fd = 0;
int client_sock_fd = 0;
int client_operation = 0;

int server_addrlen, client_addrlen;
struct sockaddr_in server_address, client_address;

void reader_run(int sock_fd);
void writer_run(int sock_fd, int position);
void *thread_routine(void *arg);

void handler(int sig_num)
{
    printf("\nSignal %d recieved\n", sig_num);

    close(server_sock_fd);

    if (semctl(sem_id, IPC_RMID, 0) == -1)
    {
        perror("Semctl error\n");
        exit(EXIT_FAILURE);
    }

    exit(EXIT_SUCCESS);
}

int main()
{
    signal(SIGINT, handler);
    
    key_t semkey = ftok(PATHNAME, 1);
    if (semkey == (key_t) -1)
    {
        perror("Ftok error\n");
        exit(EXIT_FAILURE);
    }

    perms = S_IRWXU | S_IRWXG | S_IRWXO;
    sem_id = semget(semkey, 5, perms | IPC_CREAT);
    if (sem_id == -1)
    {
        perror("Semget error\n");
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < LETTERS_COUNT; i++)
        buffer[i] = FIRST_LETTER + i;

    semctl(sem_id, ACTIVE_READER, SETVAL, 0);
    semctl(sem_id, ACTIVE_WRITER, SETVAL, 0);
    semctl(sem_id, WRITE_QUEUE, SETVAL, 0);
    semctl(sem_id, READ_QUEUE, SETVAL, 0);
    semctl(sem_id, BIN_SEM, SETVAL, 1);

    if ((server_sock_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(SERVER_PORT);
    server_address.sin_addr.s_addr = INADDR_ANY;
    server_addrlen = sizeof(server_address);

    if (bind(server_sock_fd, (struct sockaddr *) &server_address, server_addrlen) < 0)
    {
        perror("Bind failed");
        close(server_sock_fd);
        exit(EXIT_FAILURE);
    }

    if (listen(server_sock_fd, CONNECTIONS) < 0)
    {
        perror("Listen failed");
        close(server_sock_fd);
        exit(EXIT_FAILURE);
    }

    printf("Server is listening on %s:%d\n", SERVER_IP, SERVER_PORT);

    while (1)
    {
        if ((client_sock_fd = accept(server_sock_fd, (struct sockaddr *) &client_address, (socklen_t *) &client_addrlen)) < 0)
        {
            perror("Accept failed");
            close(server_sock_fd);
            exit(EXIT_FAILURE);
        }

        int *arg = (int *) malloc(sizeof(int));
        if (arg == NULL)
        {
            perror("Malloc failed");
            close(client_sock_fd);
            close(server_sock_fd);
            exit(EXIT_FAILURE);
        }

        *arg = client_sock_fd;
        if (pthread_create(&tid, NULL, thread_routine, arg) != 0)
        {
            perror("Thread create failed");
            close(client_sock_fd);
            close(server_sock_fd);
            exit(EXIT_FAILURE);
        }

        if (pthread_detach(tid) != 0)
        {
            perror("Thread detach failed");
            close(client_sock_fd);
            close(server_sock_fd);
            exit(EXIT_FAILURE);
        }
    }

    close(server_sock_fd);

    if (semctl(sem_id, IPC_RMID, 0) == -1)
    {
        perror("Semctl error\n");
        exit(EXIT_FAILURE);
    }

    exit(EXIT_SUCCESS);
}

void *thread_routine(void *arg)
{
    int clnt_sock_fd = *((int *) arg);
    free(arg);

    while (1) 
    {
        int bytes_received = read(clnt_sock_fd, &client_operation, sizeof(int));
        if (bytes_received < 0)
        {
            perror("Read failed");
            close(clnt_sock_fd);
            close(server_sock_fd);
            exit(EXIT_FAILURE);
        }

        if (client_operation == READ_OPERATION)
        {
            reader_run(clnt_sock_fd);
        }
        else
        {
            int position = client_operation;
            writer_run(clnt_sock_fd, position);
            break;
        }
    }

    close(clnt_sock_fd);
    pthread_exit(EXIT_SUCCESS);
}

void reader_run(int sock_fd)
{
    if (semop(sem_id, start_read, 5) == -1)
    {
        perror("semop:");
        fprintf(stderr, "%d semop err: %d\n", getpid(), errno);
        exit(EXIT_FAILURE);
    }

    send(sock_fd, buffer, LETTERS_COUNT, 0);

    if (semop(sem_id, stop_read, 1) == -1)
    {
        perror("semop:");
        fprintf(stderr, "%d semop err: %d\n", getpid(), errno);
        exit(EXIT_FAILURE);
    }
}

void writer_run(int sock_fd, int position)
{
    if (semop(sem_id, start_write, 5) == -1)
    {
        perror("semop:");
        fprintf(stderr, "%d semop err: %d\n", getpid(), errno);
        exit(EXIT_FAILURE);
    }

    if (buffer[position] != ' ')
    {
        printf("Position %d char:\t%c\n", position, buffer[position]);
        send(sock_fd, buffer + position, sizeof(char), 0);
        buffer[position] = ' ';
    } 
    else
    {
        char answer = POSITION_OCCUPIED;
        send(sock_fd, &answer, sizeof(char), 0);
    }

    if (semop(sem_id, stop_write, 2) == -1)
    {
        perror("semop:");
        fprintf(stderr, "%d semop err: %d\n", getpid(), errno);
        exit(EXIT_FAILURE);
    }
}