#include <dirent.h>
#include <limits.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <errno.h>
#include <string.h>

#define BLUE "\033[1;34m"
#define WHITE "\033[0m"

int tree(const char *pathname, int depth);

int main(int argc, char *argv[])
{
    if (argc != 2)
        exit(EXIT_FAILURE);

    tree(argv[1], 0);

    return EXIT_SUCCESS;
}

int print_file(const char *pathname, int depth, int is_dir)
{
    for (int i = 0; i < depth - 1; i++)
        printf("  │");

    if (depth > 0)
        printf("  ├─");

    if (is_dir)
        printf(" %s%s%s", BLUE, pathname, WHITE);
    else
        printf(" %s", pathname);
    printf("\n");

    return EXIT_SUCCESS;
}

int tree(const char *pathname, int depth)
{
    int is_dir;
    struct stat statbuf;

    if (lstat(pathname, &statbuf) < 0)
    {
        perror("error: lstat");
        exit(EXIT_FAILURE);
    }

    is_dir = S_ISDIR(statbuf.st_mode);

    print_file(pathname, depth, is_dir);

    if (is_dir)
    {
        DIR *dir = opendir(pathname);
        if (!dir)
        {
            perror("error: opendir");
            exit(EXIT_FAILURE);
        }

        if (chdir(pathname) < 0)
        {
            perror("error: chdir");
            exit(EXIT_FAILURE);
        }

        struct dirent *entry;
        while ((entry = readdir(dir)) != NULL)
        {
            if (!(strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0))
                tree(entry->d_name, depth + 1);
        }

        if (closedir(dir) < 0)
        {
            perror("error: closedir");
            exit(EXIT_FAILURE);
        };

        if (chdir("..") < 0)
        {
            perror("error: chdir ..");
            exit(EXIT_FAILURE);
        }
    }

    return EXIT_SUCCESS;
}