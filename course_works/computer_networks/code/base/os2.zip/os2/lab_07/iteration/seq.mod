/home/kori/bmstu/os2/lab_07/iteration/seq.o
