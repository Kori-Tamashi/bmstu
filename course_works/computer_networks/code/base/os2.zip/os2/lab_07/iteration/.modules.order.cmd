savedcmd_/home/kori/bmstu/os2/lab_07/iteration/modules.order := {   echo /home/kori/bmstu/os2/lab_07/iteration/seq.o; :; } > /home/kori/bmstu/os2/lab_07/iteration/modules.order
