savedcmd_/home/kori/bmstu/os2/lab_07/single/modules.order := {   echo /home/kori/bmstu/os2/lab_07/single/seq.o; :; } > /home/kori/bmstu/os2/lab_07/single/modules.order
