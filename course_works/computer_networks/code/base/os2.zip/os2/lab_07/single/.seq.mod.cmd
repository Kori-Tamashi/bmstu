savedcmd_/home/kori/bmstu/os2/lab_07/single/seq.mod := printf '%s\n'   seq.o | awk '!x[$$0]++ { print("/home/kori/bmstu/os2/lab_07/single/"$$0) }' > /home/kori/bmstu/os2/lab_07/single/seq.mod
