/home/kori/bmstu/os2/lab_07/single/seq.o
