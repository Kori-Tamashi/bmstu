#include <linux/init.h>
#include <linux/module.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/sched.h>
#include <linux/pid.h>
#include <linux/jiffies.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Mikhail Salnikov");

#define FILENAME  "fortune_file"
#define DIRNAME   "fortune_dir"
#define SYMLINK   "fortune_sym"
#define PREFIX     "+ fortune "
#define FILEPATH  DIRNAME "/" FILENAME

#define MAX_PIDS  3

static struct proc_dir_entry *seqDir;
static struct proc_dir_entry *seqFile;
static struct proc_dir_entry *seqLink;

static pid_t target_pids[MAX_PIDS] = {-1, -1, -1};
static int pids_count = 0;

static int single_show(struct seq_file *m, void *v)
{
    int i;
    struct task_struct *task;

    printk(KERN_INFO PREFIX "show\n");
    printk(KERN_INFO PREFIX "m = %p, v = %p\n", m, v);

    if (pids_count == 0)
    {
        seq_printf(m, "No PIDs specified.\n");
        return 0;
    }

    for (i = 0; i < pids_count; i++)
    {
        pid_t pid = target_pids[i];

        task = get_pid_task(find_get_pid(pid), PIDTYPE_PID);

        if (task)
        {
            seq_printf(m,
                       "Process information for PID %d:\n"
                       "Policy:   %d\n"
                       "Priority: %d\n"
                       "Flags:    %#x\n"
                       "State:    %#x\n"
                       "stime:    %llu\n"
                       "utime:    %llu\n\n",
                       pid,
                       task->policy,
                       task->prio,
                       task->flags,
                       task->__state,
                       (unsigned long long) task->stime,
                       (unsigned long long) task->utime
            );

            put_task_struct(task);
        }
        else
        {
            seq_printf(m, "Process with PID %d not found.\n\n", pid);
        }
    }

    return 0;
}

static int my_open(struct inode *inode, struct file *file)
{
    printk(KERN_INFO PREFIX "open\n");
    return single_open(file, single_show, NULL);
}

static ssize_t my_read(struct file *file, char __user *buf, size_t len, loff_t *ppos)
{
    printk(KERN_INFO PREFIX "read\n");
    printk(KERN_INFO PREFIX "pos = %lld\n", *ppos);
    return seq_read(file, buf, len, ppos);
}

static ssize_t my_write(struct file *file, const char __user *buf, size_t len, loff_t *ppos)
{
    char pid_buf[32];
    int pid;

    printk(KERN_INFO PREFIX "write\n");

    if (len > sizeof(pid_buf) - 1)
        return -EINVAL;

    if (copy_from_user(pid_buf, buf, len))
        return -EFAULT;

    pid_buf[len] = '\0';

    if (pids_count >= MAX_PIDS)
        return -EINVAL;

    if (kstrtoint(pid_buf, 10, &pid))
        return -EINVAL;

    target_pids[pids_count++] = pid;
    return len;
}

static int my_release(struct inode *inode, struct file *file)
{
    printk(KERN_INFO PREFIX "release\n");
    return single_release(inode, file);
}

static const struct proc_ops fops = {
        .proc_open    = my_open,
        .proc_read    = my_read,
        .proc_write   = my_write,
        .proc_release = my_release,
};

static void free_resources(void)
{
    if (seqLink)
        remove_proc_entry(SYMLINK, NULL);
    if (seqFile)
        remove_proc_entry(FILENAME, seqDir);
    if (seqDir)
        remove_proc_entry(DIRNAME, NULL);
}

static int __init md_init(void)
{
    printk(KERN_INFO PREFIX "md_init\n");
    seqDir = proc_mkdir(DIRNAME, NULL);
    if (!seqDir)
        return -ENOMEM;

    seqFile = proc_create(FILENAME, 0666, seqDir, &fops);
    if (!seqFile)
    {
        free_resources();
        return -ENOMEM;
    }

    seqLink = proc_symlink(SYMLINK, NULL, FILEPATH);
    if (!seqLink)
    {
        free_resources();
        return -ENOMEM;
    }

    printk(KERN_INFO PREFIX "Module loaded\n");
    return 0;
}

static void __exit md_exit(void)
{
    free_resources();
    printk(KERN_INFO PREFIX "Module unloaded\n");
}

module_init(md_init);
module_exit(md_exit);
